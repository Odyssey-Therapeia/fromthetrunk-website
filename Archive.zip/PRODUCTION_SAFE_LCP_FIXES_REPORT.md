# FTT Production Safe LCP Fixes Report

Date: 2026-07-01

## Safe Fixes Applied

| File | Change | Visible content impact |
| --- | --- | --- |
| `app/(site)/our-story/page.tsx` | Added `fetchPriority="high"` to the cover `Image` that already had `priority` | None |
| `app/(site)/our-story/page.tsx` | Replaced route-local wrapper `main` tags with `div` tags under the existing site layout `main` | None intended |
| `app/(site)/collection/page.tsx` | Replaced the route-local wrapper `main` tag with a `div` under the existing site layout `main` | None intended |
| `components/layout/site-header.tsx` | Changed logo image alt to decorative empty alt because the enclosing link already has an `sr-only` name | No visible content change |
| `components/layout/site-header-server.tsx` | Same decorative logo alt fix for server header | No visible content change |

## What Was Not Changed

- No copy or written content was changed.
- No routes were added, removed, or renamed.
- No checkout, cart, payment, auth, OTP, Razorpay, shipping, order, wishlist, pricing, stock, availability, DB schema, migration, or production-data logic was changed.
- No media deletion or live media replacement was performed.
- No homepage video/media rewrite was performed.

## Verification

- `pnpm exec tsc --noEmit --pretty false`: pass.
- `pnpm run lint`: pass.
- `pnpm run build`: pass.
- Focused axe check on `/`, `/collection`, `/our-story`, and `/policies/privacy-policy`: 0 violations after fixes.
- Required `pnpm run agent:check`: failed on public mobile LCP, after passing tests, lint, and build.

## Result

The safe fix improved image discovery and removed sampled accessibility violations, but it did not resolve the production mobile LCP blocker.
