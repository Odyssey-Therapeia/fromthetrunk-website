# Backlink And Digital PR Master Plan

Date: 2026-07-01

Planning only. No outreach was sent.

## Positioning Angles

- Circular luxury sarees.
- Founder story and textile memory.
- Pre-loved Indian fashion with authentication and restoration.
- Saree care and fabric education.
- Bengaluru/India sustainable commerce story.

## Target Pages

- `/our-story`
- `/our-team`
- `/how-it-works`
- `/collection`
- `/sell-your-saree`
- `/faqs`
- `/why`
- Future approved care/fabric/sustainable guide pages.

## 30-Day Post-Launch Plan

1. Verify production SEO and Search Console.
2. Confirm top linkable pages are final and visually approved.
3. Build a reviewed outreach list of 25-50 high-fit publications.
4. Prioritize founder/circular-fashion/local story pitches.
5. Track all outreach manually.

## 90-Day Plan

1. Publish approved care/fabric guide assets.
2. Pitch resource links to craft, handloom, wedding, and sustainability publishers.
3. Monitor unlinked mentions.
4. Review backlink quality monthly.
5. Avoid paid dofollow, PBN, spam, fake awards, fake reviews, and mass directory submissions.

## Execution Status

Backlink outreach execution: `NO-GO until site is live, list is reviewed, no-spam policy is accepted, and user explicitly approves outreach`.

