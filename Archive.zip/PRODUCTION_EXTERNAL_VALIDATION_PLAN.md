# Production External Validation Plan

Date: 2026-07-01
Status: plan only, no external actions performed

## Do Not Perform Until Approved

- deploy production
- submit sitemap
- request indexing
- run production migrations
- trigger live payment
- change Vercel env
- outreach/backlink submission

## After Deployment Approval

1. Verify production route status:
   - `/`
   - `/collection`
   - one live PDP
   - `/sitemap.xml`
   - `/robots.txt`
   - `/llms.txt`
   - policy pages
   - cart/checkout noindex routes

2. Verify production SEO origins:
   - canonical links
   - Open Graph URLs
   - JSON-LD URLs
   - sitemap `<loc>` values
   - robots sitemap URL
   - `llms.txt` URLs

3. Verify production security:
   - headers
   - CSP report-only endpoint
   - API docs hidden unless approved
   - health route status

4. Verify Search Console:
   - property matches `https://www.fromthetrunk.shop`
   - sitemap fetch succeeds
   - robots parser permits public pages
   - URL inspection for home, collection, PDP, guides, policies

5. Verify Core Web Vitals:
   - Vercel Speed Insights
   - Lighthouse mobile on production
   - page weight and LCP element identification

6. Verify commerce:
   - account sign-in
   - OTP delivery
   - add to cart
   - checkout
   - Razorpay payment link / payment callback
   - webhook signature and event id dedupe
   - receipt page

7. Verify analytics:
   - GTM/GA4 only when approved
   - no admin route tracking
   - no PII leakage in analytics payloads

## Acceptance Evidence Required

- screenshots or logs from live production
- Search Console sitemap fetch result
- Lighthouse/Speed Insights evidence
- payment/webhook test evidence
- owner approval for any accepted risk
