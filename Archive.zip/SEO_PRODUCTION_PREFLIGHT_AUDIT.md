# Production SEO Preflight Audit

Date: 2026-07-01

## Local Production-Style Output

- Built with `next build`.
- Served with `next start --hostname 127.0.0.1 --port 3000`.
- `robots.txt` points to `https://www.fromthetrunk.shop/sitemap.xml`.
- `sitemap.xml` emits production canonical URLs.
- `llms.txt` emits production canonical public links.

## Pass

- Canonical origin fallback is `https://www.fromthetrunk.shop`.
- No localhost or `.vercel.app` found in checked page canonicals.
- Sitemap contains canonical public URLs.
- Robots disallows private/system routes.
- `/policies/[slug]` is the canonical policy family in sitemap.
- Legacy policy routes redirect permanently.
- `/founders` redirects permanently to `/our-team`.
- `/faqs`, `/why`, and `/sell-your-saree` are indexable and mapped.
- Cart/checkout/account/search/admin/api are not sitemap targets.
- Query-filter URLs do not enter sitemap.
- Product JSON-LD guardrails prevent fake rating/review schema.
- FAQ schema is tied to visible FAQ content.
- Product image URL helper filters unsafe URLs.
- Welcoming WebM is first and poster exists.

## Fail Or Blocked

- `pnpm-lock.yaml` is deleted, blocking `pnpm audit` and reproducibility.
- `agent:check` failed in public mobile LHCI because all configured public-mobile routes exceeded the 2500 ms LCP budget.
- The earlier `/policies/terms-of-service` LHCI 500 did not reproduce during `agent:check`.
- Live production image URL 200 checks require deployed production.
- Search Console property verification and sitemap submission were not performed.

## Status

Production SEO preflight: `NO-GO until lockfile, UX gate, and performance exceptions are resolved or accepted`.
