# Production API Observability Audit

Date: 2026-07-01
Result: CONDITIONAL NO-GO

## API Surface

Hono app is mounted under `/api/v2`.

Observed route groups include:

- products
- product types
- tags
- collections
- orders
- users
- auth OTP
- addresses
- wishlist
- events
- media
- newsletter
- contact
- site feedback
- search
- geo
- security
- social
- globals
- cart
- payments
- webhooks
- cron
- admin routes
- conversations
- feeds
- health

## Health Route

`/api/v2/health` returned 200 locally.

Route code reports:

- status
- checks
- timestamp

## Server Timing

Sampled page responses include `Server-Timing: proxy;dur=...`.

## API Docs

Local:

- `/api/v2/docs`: 200
- `/api/v2/openapi.json`: 200

Code policy:

```text
NODE_ENV !== "production" || FTT_ENABLE_API_DOCS === "true"
```

Production must verify docs are not exposed unless intentionally approved.

## Analytics / Error Tracking

Observed code paths:

- Vercel Analytics and Speed Insights in site layout.
- GTM script is env-gated.
- GA4 Measurement Protocol sink is env-gated.
- Meta CAPI sink is env-gated.
- Sentry adapter is env-gated and no-op when `SENTRY_DSN` absent.
- Channel metrics adapters are env-gated.

## Gaps

Not validated:

- production Vercel Speed Insights data
- production error tracker event capture
- production health monitor
- production API docs exposure
- production logs/drain integration
- cron success/failure monitoring

## Decision

NO-GO until:

- observability envs are confirmed,
- API docs exposure is confirmed,
- production health monitoring is configured,
- cron monitoring is approved.
