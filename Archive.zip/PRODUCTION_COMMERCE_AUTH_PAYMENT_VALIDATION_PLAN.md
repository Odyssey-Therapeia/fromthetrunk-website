# FTT Production Commerce Auth Payment Validation Plan

Date: 2026-07-01

## Scope Boundary

This sprint did not modify commerce, auth, payment, OTP, Razorpay, shipping, order, wishlist, stock, availability, pricing, DB schema, migrations, or production data.

## Automated Coverage Run

`pnpm run test` passed:

- 134 test files.
- 1679 tests.

Relevant test names present in the suite include payment route tests, webhook route/signature tests, complete-paid-order tests, order charge totals tests, customer account tests, receipt HTML tests, and cart/order related unit coverage.

## Required Manual Production/Preview Checks

Before production push, run non-destructive checks in preview/staging:

1. Guest cart add/remove and quantity behavior.
2. Signed-in cart add/remove and quantity behavior.
3. Checkout page load without payment submission.
4. Razorpay test-mode payment happy path in preview only.
5. Razorpay webhook signature handling in preview only.
6. Order confirmation and receipt route visibility for the owning customer.
7. Account order list and detail ownership checks.
8. Wishlist ownership checks.
9. OTP and email-auth sign-in flow.
10. Admin order detail and packing slip read-only view.

## Production Status

Automated tests pass, but the dirty tree includes high-risk commerce/auth/payment/schema files. Production sign-off still requires owner review and preview smoke testing of the exact branch state.
