# Metadata, Schema, Canonical, And Route Map Recheck

Date: 2026-07-01

## Public Indexable Routes

| Route Group | Canonical | Schema | Status |
| --- | --- | --- | --- |
| `/` | Production absolute URL | Organization/WebSite from site layout | OK |
| `/collection` | Query-free production canonical when filters are absent | Collection/product cards | OK |
| `/collection/[slug]` | Product production canonical | Product + BreadcrumbList | OK |
| `/our-story` | Production canonical | Page metadata | OK |
| `/our-team` | Production canonical | Page metadata | OK |
| `/how-it-works` | Production canonical | Page metadata | User-owned dirty route, no edit |
| `/packing` | Production canonical | Page metadata | OK |
| `/policies` | Production canonical | Page metadata | OK |
| `/policies/[slug]` | Canonical policy family | Page metadata | OK |
| `/faqs` | Production canonical | FAQPage | OK |
| `/why` | Production canonical | Page metadata | OK |
| `/sell-your-saree` | Production canonical | Keyword guide/FAQ/breadcrumb pipeline | OK |
| `/guides/[slug]` | Production canonical from keyword config | Guide/FAQ/breadcrumb where configured | OK |
| Eligible keyword pages | Production canonical from keyword config | ItemList/FAQ/breadcrumb where configured | OK |

## Private/Noindex Routes

- `/cart`
- `/checkout`
- `/account`
- `/wishlist`
- `/search`
- `/admin`
- `/api`

These are not sitemap SEO targets. Robots disallows relevant private/system families.

## Safety Checks

- No fake review/rating schema found in SEO test guardrails.
- Canonical policy family is `/policies/[slug]`.
- Legacy top-level policy routes are redirected and excluded from sitemap.
- Query-filter URLs are excluded from sitemap.
- `SITE_URL` fallback rejects localhost and `.vercel.app` production origins.

