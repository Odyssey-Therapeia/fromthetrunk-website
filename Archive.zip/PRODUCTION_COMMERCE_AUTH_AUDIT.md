# Production Commerce Auth Audit

Date: 2026-07-01
Result: NO-GO until owner sign-off and live/sandbox transaction validation

## Protected Boundaries

The user explicitly prohibited changes to:

- checkout
- payment
- Razorpay
- cart
- auth
- OTP
- order logic
- wishlist
- database and migrations
- product pricing/stock/availability/reservation/business logic

This audit did not change those systems.

## Test Evidence

`pnpm run test` passed:

- 134 test files
- 1679 tests

The test output included expected failure-path logs from mocked tests and missing test env paths, but the command exited successfully.

## Commerce Route Status

Local route sampler:

- `/cart`: 200, noindex/nofollow
- `/checkout`: 200, noindex/nofollow
- `/checkout/confirmation/*`: present in route map
- `/api/v2/payments/*`: code present
- `/api/v2/webhooks/razorpay`: code present

## Auth Route Status

Local route sampler:

- `/account`: 200, noindex/nofollow
- `/account/profile`: 307 to `/account/sign-in?callbackUrl=...`

Code evidence:

- `proxy.ts` protects account profile/order/address/wishlist paths.
- Hono auth middleware reads NextAuth JWT.
- OTP routes and account UI are present.

## Payment Security Evidence

Code evidence:

- Razorpay credentials required for instance creation.
- Payment signatures use HMAC and timing-safe comparison.
- Payment Link redirect signature verification exists.
- Webhook route verifies `x-razorpay-signature`.
- Webhook event id is claimed to prevent duplicate processing.

## Gaps

Not performed:

- live Razorpay test payment
- live webhook delivery validation
- production callback URL validation
- OTP email delivery validation
- account login/logout manual browser test
- order confirmation receipt download validation
- stock/reservation manual race test

Local readiness gaps:

- `CRON_SECRET` missing
- `ADMIN_API_SECRET` missing
- OAuth provider pair missing
- auth/public URL mismatch in local env

## Decision

NO-GO until:

- production env is verified,
- payment credentials are confirmed live and consistent,
- webhook endpoint/signature is tested,
- owner signs off dirty checkout/payment/auth/order/database changes.
