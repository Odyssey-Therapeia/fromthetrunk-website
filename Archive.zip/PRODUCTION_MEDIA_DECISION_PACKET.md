# FTT Production Media Decision Packet

Date: 2026-07-01

## Scope

This sprint did not delete, replace, or re-compress live media.

## Observed Media Risk

- Tracked banner assets are deleted in the working tree: `public/banner/banner1.png`, `banner2.gif`, `banner3.png`, and `banner4.png`.
- Replacement AVIF assets are untracked: `public/banner/banner1.avif`, `banner2.avif`, `banner3.avif`, and `banner4.avif`.
- Additional untracked media exists under `public/footer/`, `public/our-story/`, `public/seo-candidates/`, plus `public/Welcoming.webm`, `public/welcome-poster.avif`, and `public/welcome.webp`.

## Decision Needed

Before production, owner approval is required for any of these media actions:

- Accepting tracked banner deletions.
- Switching references from PNG/GIF to AVIF.
- Replacing hero or homepage video/poster assets.
- Committing untracked media folders.
- Deleting `public/seo-candidates/` or other candidate assets.

## Current Sprint Action

No media file was changed by this blocker sprint. Media remains a production review item because the working tree already contains asset deletion/replacement candidates.
