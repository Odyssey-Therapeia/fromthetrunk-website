# Internal Linking Backlink Support

Date: 2026-07-01

## Linkable Target Support

| Target | Existing Internal Support | Recommended Future Support |
| --- | --- | --- |
| `/our-story` | header/footer/home sections | press/media kit if approved |
| `/our-team` | header/sitemap/llms | founder story PR links |
| `/how-it-works` | header/footer/sitemap/llms | link from future care/fabric guides |
| `/collection` | global nav and many CTAs | link from all approved guide pages |
| `/sell-your-saree` | footer/sitemap/llms/keyword page | link from future sustainable/care content |
| `/faqs` | policy pages/footer | link from all new support guides |
| `/why` | header/sitemap/llms | link from future sustainable story assets |
| future care/fabric/sustainable guides | none yet | add after approval only |

## Constraint

Do not change visible anchors or add visible sections without content approval.

