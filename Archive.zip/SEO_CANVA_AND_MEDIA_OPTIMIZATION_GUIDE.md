# Canva And Media Optimization Guide

Date: 2026-07-01

## Image Workflow

- Canva source export: high-quality PNG or JPG.
- Website delivery: WebP through Next Image/CDN where possible.
- AVIF: use as comparison candidate only until visual approval across Safari/Chrome/mobile.
- Product, editorial, saree, founder, and story photos must not be converted to SVG.
- Preserve crop, color, lighting, framing, and textile representation.
- Use desktop/tablet/mobile variants for large above-fold visuals when needed.
- Use lowercase hyphenated filenames, for example `saree-care-guide-hero.webp`.

## Video Workflow

- Canva source export: MP4.
- Website final: WebM first when converted and visually approved.
- Keep optimized MP4 fallback when needed for browser support.
- Use a WebP/AVIF poster frame.
- Use `preload="none"` or `preload="metadata"` unless the video is a verified LCP-critical hero.
- Avoid GIF for performance.
- Do not load decorative video before first paint.

## Logos And Icons

- Use SVG only for true vector assets.
- Avoid SVG files with embedded raster/base64 payloads.
- Keep SVGs sanitized and small.
- Do not enable broad SVG delivery without CSP/security review.

## OG And Social

- Prefer 1200x630 PNG/JPG or generated OG route.
- Product pages should use representative product images.
- OG image URLs must be production HTTPS, not localhost or preview domains.

## Target Delivery Sizes

- Hero WebP: ideally 300-500 KB final display asset.
- Below-fold editorial WebP: ideally 150-250 KB.
- Early video: ideally under 2-4 MB and deferred if decorative.
- Product images: use responsive derivatives from the image pipeline/CDN, not huge originals on mobile.

## FTT Brand Guardrails

- Ivory base, navy trust/structure, gold sparingly, burgundy only for urgency/destructive/sold/heat states.
- Do not recolor or distort the logo.
- Do not use generic stock-style SEO art for guides.
- Use real saree/story/product imagery where the user needs to inspect the thing.

