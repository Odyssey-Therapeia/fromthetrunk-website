# Production Route Status Audit

Date: 2026-07-01
Result: CONDITIONAL NO-GO

Scope: local built server at `http://127.0.0.1:3000` plus a controlled production-origin env check on `http://127.0.0.1:3001`.

## Core Route Results

Sampled routes returned:

| Route | Status | Notes |
| --- | ---: | --- |
| `/` | 200 | Rendered home |
| `/collection` | 200 | Rendered collection |
| `/collection/stretchfit-blouse` | 200 | Rendered PDP |
| `/our-story` | 200 | Rendered |
| `/our-team` | 200 | Rendered |
| `/how-it-works` | 200 | Rendered |
| `/packing` | 200 | Rendered |
| `/policies` | 200 | Rendered |
| `/policies/privacy-policy` | 200 | Rendered |
| `/policies/terms-of-service` | 200 | Rendered |
| `/policies/shipping-delivery-policy` | 200 | Rendered |
| `/policies/return-refund-policy` | 200 | Rendered |
| `/faqs` | 200 | Rendered |
| `/why` | 200 | Rendered |
| `/sell-your-saree` | 200 | Rendered |
| `/guides/what-is-a-pre-loved-saree` | 200 | Rendered |
| `/guides/pre-loved-vs-second-hand-saree` | 200 | Rendered |
| `/cart` | 200 | noindex |
| `/checkout` | 200 | noindex |
| `/account` | 200 | noindex |
| `/account/profile` | 307 | Redirects unauthenticated user to sign-in |
| `/search` | 200 | noindex |
| `/admin` | 200 | local sample rendered; admin auth state not fully validated |
| `/sitemap.xml` | 200 | XML |
| `/robots.txt` | 200 | text |
| `/llms.txt` | 200 | text |
| `/api/v2/health` | 200 | JSON healthy |
| `/api/v2/docs` | 200 | Swagger exposed in local env |
| `/api/v2/openapi.json` | 200 | OpenAPI exposed in local env |

## Redirects

Expected redirects were present:

| Route | Status | Location |
| --- | ---: | --- |
| `/privacy-policy` | 308 | `/policies/privacy-policy` |
| `/terms-of-service` | 308 | `/policies/terms-of-service` |
| `/shipping-policy` | 308 | `/policies/shipping-delivery-policy` |
| `/return-policy` | 308 | `/policies/return-refund-policy` |
| `/founders` | 308 | `/our-team` |

## Metadata Endpoints

Headers checked with `curl -I`:

- `/`
- `/sitemap.xml`
- `/robots.txt`
- `/llms.txt`

All returned 200 locally.

## Route Risks

- Local `/api/v2/docs` and `/api/v2/openapi.json` are exposed. Code gates docs via `NODE_ENV !== "production" || FTT_ENABLE_API_DOCS === "true"`, so production must confirm `FTT_ENABLE_API_DOCS` is not enabled unless intentionally approved.
- Local canonical/sitemap/robots/llms origins emitted localhost until production URL env overrides were supplied.
- `/admin` local route returned 200 in the sampled unauthenticated state. Admin auth/authorization needs a separate authenticated production sign-off.

## Decision

Route status is broadly functional, but production route readiness remains NO-GO until:

- Production env emits production origins.
- API docs exposure is verified off or explicitly approved.
- Admin auth and commerce flows are manually signed off.
