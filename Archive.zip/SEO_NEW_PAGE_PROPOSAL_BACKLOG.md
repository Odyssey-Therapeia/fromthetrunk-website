# New SEO Page Proposal Backlog

Date: 2026-07-01

No new pages were created in this phase.

## Proposed Pages

| Proposed URL | Purpose | Intent | Proposed H1 | Schema | Sitemap Rule | Approval |
| --- | --- | --- | --- | --- | --- | --- |
| `/guides/saree-care-guide` | Care/storage resource and linkable asset | informational | Saree Care Guide | Article/FAQPage if FAQ visible | include after final content approval | required |
| `/guides/saree-fabric-guide` | Fabric education and internal links to collection filters | informational/commercial | Saree Fabric Guide | Article/BreadcrumbList | include after final content approval | required |
| `/guides/sustainable-sarees` | Circular fashion positioning | informational | Sustainable Sarees | Article/FAQPage if FAQ visible | include after final content approval | required |
| `/guides/pre-loved-sarees-guide` | Broader pre-loved guide | informational | Pre-Loved Sarees Guide | Article | likely map to existing `/guides/what-is-a-pre-loved-saree` to avoid duplication | required |
| `/press` or `/media-kit` | PR/backlink support | navigational/press | Press & Media Kit | Organization/ProfilePage | include only after assets/copy approved | required |
| Founder story PR page | Founder story asset | PR/editorial | Founder Story | ProfilePage/Article | likely covered by `/our-team`; avoid duplicate until brief approved | required |

## Brand Template Requirements

- Ivory base with navy panels.
- Gold only as accents.
- Editorial imagery, not generic blog stock.
- Cormorant display headings and Jost body/UI.
- Pill CTAs.
- No keyword stuffing.
- Internal links to collection, story, how-it-works, relevant policies, and approved guides.

