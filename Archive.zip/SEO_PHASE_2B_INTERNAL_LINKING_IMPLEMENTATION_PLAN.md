# SEO Phase 2B Internal Linking Implementation Plan

Date: June 30, 2026

Do not implement these visible links until approved. Use canonical `/policies/[slug]` URLs.

## Recommended Links

| Source | Destination | Suggested anchor text | Approval needed |
|---|---|---|---|
| Homepage | `/collection` | Browse the collection | Yes, visible anchor placement/copy. |
| Homepage | `/our-story` | Read our story | Yes. |
| Homepage | `/how-it-works` | See how it works | Yes. |
| Homepage | `/faqs` | Read FAQs | Yes. |
| Homepage | `/sell-your-saree` | Sell your saree | Yes. |
| Homepage | `/why` | Why we do this | Yes. |
| Collection | `/how-it-works` | How each saree is reviewed | Yes. |
| Collection | `/packing` | Packing and dispatch care | Yes. |
| Collection | `/our-story` | The From the Trunk story | Yes. |
| Collection | `/faqs` | Collection FAQs | Yes. |
| PDP | `/how-it-works` | How we authenticate and restore | Yes. |
| PDP | `/packing` | How your saree is packed | Yes. |
| PDP | `/policies/shipping-delivery-policy` | Shipping policy | Yes. |
| PDP | `/policies/return-refund-policy` | Return policy | Yes. |
| FAQ | `/policies/shipping-delivery-policy` | Shipping and delivery policy | Likely already covered; only add if content owner approves. |
| FAQ | `/policies/return-refund-policy` | Return, refund, and exchange policy | Likely already covered; only add if content owner approves. |
| Policy detail | `/faqs` | FAQs | Yes. |
| Policy detail | Related `/policies/[slug]` pages | Related policy names | Yes. |
| Our Story | `/collection` | Explore the collection | Existing. |
| Our Story | `/how-it-works` | See how it works | Yes. |
| Our Story | `/our-team` | Meet the team | Yes. |
| Why | `/collection` | Explore the collection | Existing. |
| Why | `/how-it-works` | See how it works | Yes. |
| Why | `/our-story` | Read the story | Current page links to `/our-team`; any text/target change needs approval. |
| Guides | `/collection` | Browse the collection | Existing in keyword pages. |
| Guides | `/sell-your-saree` | Sell your saree | Existing in keyword pages. |

## Implementation Rules For Phase 2B

- Keep visible anchor text changes approval-gated.
- Do not add new guide pages yet.
- Do not link to cart, checkout, account, search, admin, API, or query-filter URLs as SEO targets.
- Use canonical policy URLs only.
- Prefer editorial/support link modules over dense link stuffing.
- Preserve existing page copy unless explicit copy approval is given.
