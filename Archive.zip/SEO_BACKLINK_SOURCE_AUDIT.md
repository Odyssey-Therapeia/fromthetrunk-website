# Backlink Source Audit

Date: 2026-07-01

## Opportunity Classes

| Class | Fit | Notes |
| --- | --- | --- |
| Fashion media | high | Founder/story/product positioning |
| Sustainability publication | high | Circular fashion angle |
| Craft/handloom blog | high | Textile care/fabric guide assets |
| Wedding/lifestyle blog | medium-high | Styling and heirloom saree angle |
| Podcast/interview | medium-high | Founder story |
| Local Bengaluru/India publication | high | Local business/circular fashion story |
| Marketplace/commerce directory | medium | Only high-quality relevant listings |
| Generic directory | low | Avoid unless highly relevant |
| Spam/low quality | avoid | Never pursue |

## Scoring Template

- Relevance: 1-5
- Authority: 1-5
- Outreach difficulty: 1-5
- Spam risk: 1-5
- Brand fit: 1-5
- Recommendation: pursue, monitor, or avoid.

