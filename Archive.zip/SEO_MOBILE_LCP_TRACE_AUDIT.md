# Mobile LCP Trace Audit

Date: 2026-07-01

## LHCI Result

`npx -y -p node@22 -p pnpm@10.28.0 pnpm run verify:ux` built successfully and started the public mobile LHCI run. The run stopped before the full matrix because LHCI reported `ERRORED_DOCUMENT_REQUEST` with status 500 for `/policies/terms-of-service`.

A direct built-server check immediately after returned:

- `/policies/terms-of-service`: `200 OK`
- `/terms-of-service`: `308 Permanent Redirect` to `/policies/terms-of-service`

`npx -y -p node@22 -p pnpm@10.28.0 pnpm run agent:check` was then run. The `verify` portion passed, and the public mobile LHCI collection completed all configured public-mobile URLs. The previous `/policies/terms-of-service` 500 did not reproduce. `agent:check` still failed because every checked public-mobile route exceeded the configured 2500 ms LCP assertion.

## Latest Completed Public Mobile LCP Measurements

| Route | LCP | Performance Score | SEO Score | Classification |
| --- | ---: | ---: | ---: | --- |
| `/` | 5196 ms | not re-parsed | not re-parsed | improved needed; large media risk |
| `/collection` | 4818 ms | not re-parsed | not re-parsed | above budget; product grid/client cost |
| `/cart` | 4622 ms | not re-parsed | 0.66 warning | noindex transactional reference |
| `/checkout` | 4739 ms | not re-parsed | 0.66 warning | noindex transactional reference |
| `/our-story` | 4739 ms | not re-parsed | not re-parsed | above budget; editorial media route |
| `/how-it-works` | 5569 ms | not re-parsed | not re-parsed | blocked by user-owned animation/page |
| `/policies/privacy-policy` | 4216 ms | not re-parsed | not re-parsed | text route still above ideal budget |
| `/policies/terms-of-service` | 4065 ms | not re-parsed | not re-parsed | route loads; LCP above budget |
| `/policies/shipping-delivery-policy` | 4143 ms | not re-parsed | not re-parsed | route loads; LCP above budget |
| `/policies/return-refund-policy` | 4139 ms | not re-parsed | not re-parsed | route loads; LCP above budget |
| `/packing` | 4139 ms | not re-parsed | not re-parsed | text route still above ideal budget |

## Routes Not Covered By Current Public Mobile LHCI Config

- `/faqs`
- `/why`
- `/sell-your-saree`
- Live PDP sample
- Public desktop matrix
- Admin mobile/desktop matrix

## Likely Sources

- Large live media assets remain on homepage/landing/editorial routes.
- `app/(site)/layout.tsx` includes global analytics and widgets; analytics is non-blocking but local script MIME errors appear under `next start`.
- Site header/footer and static pages are shared across all public routes, so render delay affects text pages too.
- `how-it-works` is user-owned and animation-heavy; no code change was made.

## Safe Fixes Identified

- Replace large live media with approved candidates after visual QA.
- Keep analytics non-blocking.
- Keep policy/FAQ/support pages server-first.
- Avoid loading intro video on mobile or reduced-motion paths; current code already gates intro behavior.
- Rerun LHCI after lockfile and route failure are resolved.

## Approval-Required Fixes

- Live hero/editorial/video asset swaps.
- How-it-works animation optimization.
- Any visible section removal, redesign, or copy edit.
