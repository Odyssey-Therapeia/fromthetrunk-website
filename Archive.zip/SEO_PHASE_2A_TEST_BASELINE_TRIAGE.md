# SEO Phase 2A Test Baseline Triage

Date: June 30, 2026

Scope: the four previously failing block/homepage test files only. No visible website copy was changed.

## Summary

The red baseline was a real validation bug in the block content system, not an SEO failure and not an accepted baseline exception. The block registry contract says `propsSchema` validates props before render, but several schemas were silently accepting invalid values. Fixing those schemas made the four failing files pass.

## Failure Classification

| Test file | Original failure pattern | Classification | Decision |
|---|---|---|---|
| `tests/unit/block-hero.test.ts` | `backgroundImage` accepted non-UUID values. | Real bug. | Fixed schema to require optional UUID. |
| `tests/unit/block-p308-new-blocks.test.ts` | `image-text-split` accepted missing/non-UUID image and invalid background. | Real bug. | Fixed schema to require image UUID and reject invalid background. |
| `tests/unit/block-p308-new-blocks.test.ts` | `story-editorial` accepted missing/empty beats, empty paragraphs, invalid layout, and invalid image. | Real bug. | Fixed schema to require 1-6 beats, 1-4 paragraphs per beat, valid layouts, and UUID image refs. |
| `tests/unit/block-p308-new-blocks.test.ts` | `newsletter-signup` accepted invalid background. | Real bug. | Fixed schema to reject invalid background. |
| `tests/unit/blocks-trust-signals.test.ts` | Missing stats defaulted to an empty row set; invalid/incomplete stats and wrong tuple arity were accepted. | Real bug. | Fixed schema to default to the existing live three trust stats and require exactly three complete rows. |
| `tests/unit/homepage-blocks.test.ts` | Blocks homepage render did not include TrustSignals content because the trust-signals block rendered null for `{}`. | Real bug caused by trust-signals schema default. | Fixed via trust-signals default, no homepage copy edits. |

## Files Safely Fixed

- `lib/content/blocks/hero.tsx`
- `lib/content/blocks/image-text-split.tsx`
- `lib/content/blocks/story-editorial.tsx`
- `lib/content/blocks/newsletter-signup.tsx`
- `lib/content/blocks/trust-signals.tsx`
- `lib/content/blocks/block-editor-schemas.ts`

## Verification

Command:

```bash
npx -y -p node@22 -p pnpm@10.28.0 pnpm exec vitest run tests/unit/block-hero.test.ts tests/unit/block-p308-new-blocks.test.ts tests/unit/blocks-trust-signals.test.ts tests/unit/homepage-blocks.test.ts --reporter=verbose
```

Result: passed, 4 files, 181 tests.

Follow-up targeted command after editor-schema sync:

```bash
npx -y -p node@22 -p pnpm@10.28.0 pnpm exec vitest run tests/unit/block-p308-new-blocks.test.ts tests/unit/blocks-trust-signals.test.ts --reporter=verbose
```

Result: passed, 2 files, 141 tests.

## Accepted Baseline Exceptions

None for these four files after the safe schema fixes.
