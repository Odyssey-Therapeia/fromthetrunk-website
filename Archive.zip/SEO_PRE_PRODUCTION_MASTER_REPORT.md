# Pre-Production SEO Master Report

Date: 2026-07-01

## Executive Summary

- SEO technical readiness: 85/100.
- Performance readiness: 55/100.
- Image SEO readiness: 80/100.
- Google Image Search code readiness: 80/100.
- Production indexing readiness: 70/100.
- Backlink/digital PR planning readiness: 75/100.
- Final production SEO decision: `NO-GO`.

The route map, canonical policy family, robots, llms, metadata, schema guardrails, and internal-link basics are in good shape locally. Production readiness is blocked by deleted `pnpm-lock.yaml`, failing public-mobile LCP assertions in `agent:check`, and required visual approval before live media replacement.

## What Changed

- Generated optimized non-live asset candidates under `public/seo-candidates/`.
- Updated a stale unit test to match the current approved `/why` page behavior without adding visible links.
- Added the SEO/preflight/backlink report bundle.

## What Did Not Change

- No existing written website content changed.
- No product crop/color/representation changed.
- No auth touched.
- No checkout logic touched.
- No payment/Razorpay logic touched.
- No cart reservation logic touched.
- No stock/pricing logic touched.
- No database schema or migration changed by this pass.
- No backlink outreach sent.
- No sitemap submitted.
- No live media references switched.

## Changed UI Page Recheck

Checked `/policies`, `/policies/privacy-policy`, `/policies/terms-of-service`, `/policies/shipping-delivery-policy`, `/policies/return-refund-policy`, `/faqs`, `/why`, and `/sell-your-saree`.

All returned 200 from local built server with production canonical URLs and one H1. `/faqs` has FAQPage schema. Policy pages use canonical `/policies/[slug]` paths.

## Performance Results

Completed LHCI mobile LCP:

| Route | LCP |
| --- | ---: |
| `/` | 5196 ms |
| `/collection` | 4818 ms |
| `/cart` | 4622 ms |
| `/checkout` | 4739 ms |
| `/our-story` | 4739 ms |
| `/how-it-works` | 5569 ms |
| `/policies/privacy-policy` | 4216 ms |
| `/policies/terms-of-service` | 4065 ms |
| `/policies/shipping-delivery-policy` | 4143 ms |
| `/policies/return-refund-policy` | 4139 ms |
| `/packing` | 4139 ms |

`verify:ux` initially failed before completing the matrix due to LHCI `ERRORED_DOCUMENT_REQUEST` for `/policies/terms-of-service`; direct curl after the failure returned `200 OK`. The later full `agent:check` did not reproduce that 500, but failed on public-mobile LCP assertions across all configured public-mobile routes.

## Asset Optimization

Largest live risks:

- `public/Welcoming.mp4`: 13.6 MB fallback.
- `public/hero/banner.png`: 11.2 MB.
- `public/hero/timeless.JPG`: 7.8 MB.
- `public/hero/banner1.png`: 6.1 MB.
- `public/Ftt_logo_navbar.svg`: 5.1 MB embedded-raster SVG.
- `public/banner/collection_banner.png`: 4.25 MB.

Candidates generated but not wired:

- Hero/banner WebP/AVIF candidates.
- Collection banner WebP/AVIF candidates.
- Home cover WebP/AVIF candidates.
- 1080p muted Welcoming MP4/WebM candidates.

## Route Map

- Sitemap: production canonical public URLs.
- Robots: production sitemap and private/system disallows.
- LLMS: canonical public pages and product links.
- Redirects: legacy policies and `/founders` redirect to canonical destinations.
- Noindex/private: cart, checkout, account, search, admin, API are not SEO targets.

## Commands

- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run lint`: passed.
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsc --noEmit --pretty false`: passed.
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run build`: passed with expected canonical fallback warnings because local env origin is localhost.
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run test`: passed after updating the stale SEO test.
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run verify:ux`: failed/incomplete due initial LHCI 500 on `/policies/terms-of-service`.
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run agent:check`: failed in public mobile LHCI on LCP assertions; tests, lint, and build passed inside the gate.
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm audit`: blocked because `pnpm-lock.yaml` is missing.
- `git diff --check`: passed after report creation.

## Remaining Blockers

Must fix before production:

- Resolve or explicitly accept deleted `pnpm-lock.yaml`.
- Rerun and pass `agent:check` or accept exact LCP exceptions.
- Decide whether large live media candidates can replace current assets after visual QA.

Can accept only with explicit approval:

- Mobile LCP above target.
- Keeping the 13.6 MB Welcoming MP4 fallback.
- Keeping large hero/editorial assets unchanged.

Post-launch backlog:

- Search Console verification and sitemap submission.
- Live product image URL validation.
- Backlink research and outreach.
- New guide pages after content approval.

## GO / NO-GO Gates

- SEO technical readiness: `GO with lockfile caveat`.
- Performance readiness: `NO-GO`.
- Product Google Image Search readiness: `NO-GO until live production image checks`.
- Search Console verification readiness: `GO for prep, not executed`.
- Sitemap submission readiness: `NO-GO`.
- Production deployment readiness from SEO perspective: `NO-GO`.
- Backlink outreach execution readiness: `NO-GO`.
