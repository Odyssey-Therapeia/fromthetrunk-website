# Production Risk Register

Date: 2026-07-01
Overall result: NO-GO

| ID | Risk | Severity | Owner action |
| --- | --- | --- | --- |
| R1 | `pnpm-lock.yaml` tracked but deleted | Blocker | Restore or explicitly approve package policy change |
| R2 | `pnpm audit` cannot run without lockfile | Blocker | Restore lockfile and rerun audit |
| R3 | Mobile LCP fails every public LHCI route | Blocker | Fix or accept dated CWV exception |
| R4 | Dirty tree spans checkout/payment/auth/API/DB/SEO/media | Blocker | File ownership review before push |
| R5 | Untracked migrations `0024` and `0025` | Blocker | Review, rehearse, and approve migration plan |
| R6 | Production env not verified | Blocker | Verify Vercel production envs |
| R7 | Local readiness missing `CRON_SECRET` and `ADMIN_API_SECRET` | High | Set/verify production secrets |
| R8 | Local URL alignment failed | High | Confirm production origins use `https://www.fromthetrunk.shop` |
| R9 | Local API docs exposed | High | Confirm docs disabled in production or approved |
| R10 | Large media assets affect LCP | High | Optimize with approval or accept risk |
| R11 | Serious axe contrast/progressbar findings | High | Fix or accept accessibility risk |
| R12 | No live payment/webhook validation | High | Run approved live/sandbox transaction test |
| R13 | No production Search Console validation | High | Validate after deployment approval |
| R14 | No source-controlled `vercel.json` found | Medium | Confirm dashboard crons/deploy config |
| R15 | Local default Node outside engine range | Medium | Use Node 22 or supported `<25` runtime |
| R16 | `tsx` scripts depend on undeclared loader | Medium | Add dependency or adjust scripts |
| R17 | CSP is report-only | Medium | Decide whether/when to enforce CSP |
| R18 | Deleted tracked banner assets | Medium | Owner approve deletions |

## Decision

Production push should not proceed until blocker risks R1 through R6 are resolved or explicitly accepted by the owner.
