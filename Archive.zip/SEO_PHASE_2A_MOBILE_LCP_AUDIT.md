# SEO Phase 2A Mobile LCP Audit

Date: June 30, 2026

Command used for the route-specific audit:

```bash
FTT_LHCI_SCOPE=public FTT_LHCI_FORM_FACTOR=mobile FTT_LHCI_RUNS=1 FTT_LHCI_OUTPUT_DIR=./test-results/lighthouse/phase-2a-mobile FTT_LHCI_URL_PATHS='/,/collection,/our-story,/how-it-works,/packing,/policies/privacy-policy,/policies/terms-of-service,/policies/shipping-delivery-policy,/policies/return-refund-policy,/collection/midnight-chiffon-saree' npx -y -p node@22 -p pnpm@10.28.0 pnpm run lhci:autorun
```

Result: failed the 2.5s LCP budget on all audited mobile routes. Reports were written under `test-results/lighthouse/phase-2a-mobile/`.

The required `pnpm run verify:ux` command also failed during the public mobile LHCI pass and stopped before desktop/admin passes. Reports were written under `test-results/lighthouse/mobile/`. The default public mobile pass used canonical policy routes and found LCP over budget on `/`, `/collection`, `/cart`, `/checkout`, `/our-story`, `/how-it-works`, the four canonical policy pages, and `/packing`; `/cart` and `/checkout` also produced SEO score warnings because they are transactional noindex routes in the UX audit set rather than public sitemap targets.

## Route Findings

| Route | LCP | LCP element | Primary cause | Oversized image involved | Above fold | `next/image` | Stable dimensions | Priority/preload | Safe fix status |
|---|---:|---|---|---|---|---|---|---|---|
| `/` | 5.1s | Lighthouse did not expose an element node. | Root document ~896ms plus render/main-thread delay; early below-hero category image transfers were visible in network. | Indirectly: category JPG originals are large, though optimized delivery was used. | Hero is above fold; category section is below hero. | Hero uses `next/image`; category cards use `next/image`. | Hero uses fill in fixed-height section; category cards have fixed card heights. | Home hero first slide is priority/high. | Implemented: header logo switched from 1.8MB `logo.png` to existing 39KB navbar PNG; below-fold fabric and campaign images set to low fetch priority. |
| `/collection` | 4.6s | Collection hero banner image. | LCP image load delay: 73% of LCP. | No large transfer after optimization; source is optimized mobile WebP. | Yes. | Yes. | Fill inside fixed min-height hero container. | First slide priority/high. | No further non-visual fix found beyond confirming priority and stable sizing. Needs deeper rendering/data latency work. |
| `/our-story` | 4.4s | Cover banner image (`kanjiverram-lcp.webp`). | Image load delay: 68%; TTFB ~767ms. | Optimized WebP transfer ~141KB. | Yes. | Yes. | Fill inside fixed cover panel. | Marked priority in code. | Implemented logo asset reduction for inline logo placements; remaining LCP needs route-level render/image scheduling review. |
| `/how-it-works` | 5.4s | Hero paragraph text. | Render delay: 87%; page is currently user-owned dirty client animation work with GSAP/framer. | No. | Yes. | No LCP image. | Layout is stable. | Not applicable. | Not touched per ownership rule. Approval/ownership required before changing this route. |
| `/packing` | 3.8s | Body paragraph text. | Render delay: 80%; static text route. | No. | Yes. | No LCP image. | Layout is stable. | Not applicable. | No safe image fix. Needs global CSS/font/script render-delay investigation. |
| `/policies/privacy-policy` | 4.0s | First policy body paragraph. | Render delay: 76%; root document ~939ms. | No. | Yes. | No LCP image. | Layout is stable. | Not applicable. | No safe image fix. Needs global text-route render-delay investigation. |
| `/policies/terms-of-service` | 3.9s | First policy body paragraph. | Render delay: 80%; root document ~792ms. | No. | Yes. | No LCP image. | Layout is stable. | Not applicable. | No safe image fix. Needs global text-route render-delay investigation. |
| `/policies/shipping-delivery-policy` | 3.8s | First policy body paragraph. | Render delay: 81%; root document ~746ms. | No. | Yes. | No LCP image. | Layout is stable. | Not applicable. | No safe image fix. Needs global text-route render-delay investigation. |
| `/policies/return-refund-policy` | 4.3s | First policy body paragraph. | Render delay: 78%; root document ~935ms. | No. | Yes. | No LCP image. | Layout is stable. | Not applicable. | No safe image fix. Needs global text-route render-delay investigation. |
| `/collection/midnight-chiffon-saree` | 5.7s | PDP gallery main image. | LCP image load delay: 82%; TTFB ~847ms. | Product image resolves to `collection_banner.png`; source is large but optimized transfer was ~49KB. | Yes. | Yes. | Fill inside stable gallery container. | PDP main image is priority. | Do not alter product image/crop. Needs product media approval/data cleanup if placeholder image is wrong. |

## Scripts, Fonts, Third Parties

- `next/font` uses `display: "swap"` for Cormorant Garamond and Jost.
- GTM is gated by `NEXT_PUBLIC_GTM_ID`; no GTM blocking issue appeared in the local route-specific run.
- Vercel Analytics and Speed Insights are present but were not identified as third-party main-thread blockers in these local reports.
- Text-only routes are dominated by render delay, not image transfer.

## Safe Performance Fixes Implemented

- Replaced small header/inline logo placements from `public/logo.png` (1.8MB source) to the already-existing `public/Ftt_logo_navbar.png` (39KB source).
- Added `fetchPriority="low"` to below-fold fabric category images.
- Added `fetchPriority="low"` to below-fold campaign banner images.
- Updated LHCI public route coverage to canonical policy URLs instead of legacy policy URLs.

## Approval-Required or Larger Work

- Do not replace product images or change product crops/colors without approval.
- Do not alter `/how-it-works` because current page and experience component are user-owned dirty work in this branch.
- Replacing large legacy visual assets with new WebP/video variants requires visual approval.
- Text-route render delay likely needs a separate global render-performance pass, not a content edit.
