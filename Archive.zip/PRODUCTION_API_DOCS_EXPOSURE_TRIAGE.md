# FTT Production API Docs Exposure Triage

Date: 2026-07-01

## Code Path

`lib/http/api-docs-policy.ts` gates API docs exposure:

- Non-production: docs can be exposed.
- Production: docs require `FTT_ENABLE_API_DOCS === "true"`.

The Hono app mounts `/api/v2/docs` and `/api/v2/openapi.json` only when the policy allows it.

## Runtime Check

Against a controlled production-mode local server:

- `/api/v2/docs`: `404`
- `/api/v2/openapi.json`: `404`

## Robots Check

`robots.txt` disallows:

- `/api/`
- `/api/debug/`
- `/api/v2/docs`
- `/api/v2/openapi.json`

## Decision

No code change was needed for this blocker. Production API docs are gated and not exposed in the local production-mode check.
