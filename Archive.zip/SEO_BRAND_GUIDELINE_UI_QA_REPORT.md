# Brand Guideline UI QA Report

Date: 2026-07-01

## Audited Routes

- `/policies/[slug]`
- `/faqs`
- `/why`
- `/sell-your-saree`
- `/collection`

## Result

No redesign was performed. The sampled pages generally follow the FTT brand system:

- Ivory page surfaces are dominant.
- Royal navy/midnight are used for structure, panels, and primary CTAs.
- Gold is used as accent/hairline/eyebrow treatment, not broad fills.
- Burgundy remains a supporting warm state color.
- Headings use the editorial serif style.
- Body, labels, navigation, and buttons use the Jost/system UI style from the project.
- Buttons are pill-shaped on the checked changed pages.
- Cards and panels use generous rounded corners and soft warm shadows.
- No logo recoloring, stretching, rotating, or off-brand treatment was observed in the checked first viewports.
- No emoji was used as a provenance/verified marker in the checked changed pages.

## Visual Evidence

Local screenshots:

- `/tmp/ftt-seo-mobile-_sell-your-saree.png`
- `/tmp/ftt-seo-mobile-_policies_terms-of-service.png`
- `/tmp/ftt-seo-desktop-_why.png`

## Recommendations Only

- Keep future SEO pages on editorial layouts, not generic blog templates.
- Avoid large gold backgrounds; use gold as rule, seal, eyebrow, or small accent.
- For any new guides, use ivory base, navy panel moments, careful gold accents, and product/story imagery.
- Keep status badges as icon plus label, not color-only.
- Do not keyword-stuff visible sections. Use structured metadata and page architecture instead.

## Approval Required

Any visible layout redesign, copy changes, new page templates, or live media swaps require owner review because the active pages are user-edited.

