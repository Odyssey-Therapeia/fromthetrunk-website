# SEO Image Alt Approval Packet

Date: June 30, 2026

This is an approval packet only. No alt text implementation was performed.

## Current State

| Surface | Current alt behavior |
|---|---|
| Product cards | `alt={product.name}` |
| PDP main gallery image | `alt={product.name}` |
| PDP thumbnails | `alt={`${product.name} thumbnail ${index + 1}`}` |
| Homepage landing product cards | `alt={product.name}` |
| Story/editorial decorative backgrounds | Several use `alt=""` where decorative. |
| Founder/team portraits | Founder images use founder names. |
| Logos | `alt="From the Trunk"` where meaningful. |

## Proposed Patterns For Approval

| Surface | Proposed pattern | Notes |
|---|---|---|
| Product card image | `[Product name], pre-loved [fabric/category if reliable] saree from From the Trunk` | Use only verified product attributes; no keyword stuffing. |
| PDP main image | `[Product name] shown as a pre-loved saree, [dominant verified fabric/detail if reliable]` | Must stay truthful to product data and photography. |
| PDP gallery variation | `[Product name] detail view ${index + 1}` or data-backed view labels if CMS supports them. | Avoid inventing blouse/border/pallu details without structured media labels. |
| Founder/team portraits | `[Founder name], [approved role] at From the Trunk` | Requires role/title approval. |
| Editorial/story images | Short factual description of the visible scene or `alt=""` if purely decorative. | Do not add SEO phrases when the image is decorative. |
| Decorative overlays/background textures | `alt=""` | Keep screen-reader noise low. |

## Approval Questions

- Should product alts include fabric/material when the product data is present but not visually obvious?
- Should condition/provenance terms appear in product alts, or only in visible PDP copy/schema?
- Are founder role titles final and approved for alt text?
- Which editorial images are meaningful content versus decorative mood imagery?

## Implementation Guardrails

- No fake attributes.
- No fake provenance details.
- No keyword stuffing.
- No product color/crop/representation changes.
- Do not implement until brand/content approval is explicit.
