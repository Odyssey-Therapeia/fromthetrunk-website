# SEO Phase 2A Asset Conversion Approval List

Date: June 30, 2026

This is an approval list only. No large PNG/JPG/GIF/MP4 asset replacement was performed.

## Implemented Without Conversion

| Asset | Size | Where used | Action |
|---|---:|---|---|
| `public/logo.png` | 1.8MB | Header and our-story inline logo placements before Phase 2A. | Switched those placements to existing `public/Ftt_logo_navbar.png` because it is the same navbar logo treatment already used by footer/email/schema. |
| `public/Ftt_logo_navbar.png` | 39KB | Footer, email templates, schema, now header/our-story logo placements. | Kept as current optimized logo source. |

## Approval-Required Conversion Candidates

| Old asset | Size | Where used | Proposed new asset | Expected benefit | Visual approval required |
|---|---:|---|---|---|---|
| `public/Welcoming.mp4` | 13.6MB | `components/sections/home-intro-gate.tsx` desktop intro overlay. | Compressed MP4/WebM pair, poster frame, shorter duration if approved. | Lower first-session transfer and less startup competition. | Yes. |
| `public/hero/banner.png` | 11.2MB | Fallbacks in fabric/social/landing sections. | `public/hero/banner.webp` or remove fallback if no longer needed. | Smaller fallback transfer if selected. | Yes. |
| `public/banner/banner2.gif` | 10.7MB | No active code reference found. | Remove after asset owner confirms it is unused, or convert to MP4/WebM if needed. | Repository and deployment weight reduction. | Yes. |
| `public/hero/timeless.JPG` | 7.8MB | Landing/social image pools and fabric fallbacks. | `public/hero/timeless.webp`. | Smaller below-fold/editorial image transfer. | Yes. |
| `public/banner/banner3.png` | 6.7MB | No active code reference found. | Remove after asset owner confirms it is unused, or replace with WebP if needed. | Repository and deployment weight reduction. | Yes. |
| `public/banner/banner4.png` | 6.4MB | No active code reference found. | Remove after asset owner confirms it is unused, or replace with WebP if needed. | Repository and deployment weight reduction. | Yes. |
| `public/hero/banner1.png` | 6.1MB | Landing/social image pools and fabric fallbacks. | `public/hero/banner1.webp`. | Smaller below-fold/editorial image transfer. | Yes. |
| `public/banner/banner1.png` | 5.6MB | No active code reference found. | Remove after asset owner confirms it is unused, or replace with WebP if needed. | Repository and deployment weight reduction. | Yes. |
| `public/Ftt_logo_navbar.svg` | 5.1MB | No active code reference found. | Remove after owner confirms unused, or replace with optimized SVG. | Repository/deployment weight reduction. | Yes. |
| `public/packaging/normalpkg-2.png` | 5.3MB | Packaging imagery. | WebP/AVIF set. | Faster packaging page/gallery load if surfaced. | Yes. |
| `public/packaging/normalpkg-1.png` | 5.0MB | Packaging imagery. | WebP/AVIF set. | Faster packaging page/gallery load if surfaced. | Yes. |
| `public/banner/collection_banner.png` | 4.3MB | Default OG image, keyword page schema, and currently one audited PDP image source. | WebP/AVIF for display contexts; keep a social-compatible OG fallback if needed. | Lower source and optimized image processing cost. | Yes, especially if used as product media. |
| `public/banner/collection-banner2.png` | 4.0MB | No active display code reference found in Phase 2A search. | Remove if unused or convert to WebP if needed. | Repository/deployment weight reduction. | Yes. |
| `public/media/home-cover.png` | 3.0MB | Homepage CMS hero fallback, why/social/landing pools, fabric fallback. | WebP/AVIF replacement after visual check. | Smaller editorial/fallback transfers. | Yes. |

## Notes

- The current homepage hero already uses small `public/hero/*-lcp.webp` and `public/hero/mobile_*-lcp.webp` files.
- Product media must not be converted, cropped, recolored, or replaced without explicit approval.
- Unused asset deletion should be a separate cleanup with owner confirmation.
