# SEO Phase 2A Baseline, LCP, And Internal Linking Report

Date: June 30, 2026

## Test Baseline Decision

The previous block/homepage failures were real block-schema validation bugs, not accepted SEO baseline failures. They were fixed without changing visible website copy.

Targeted baseline result: 4 files passed, 181 tests passed.

## Files Changed In Phase 2A

- `app/(site)/our-story/page.tsx`
- `components/layout/site-header-server.tsx`
- `components/layout/site-header.tsx`
- `components/sections/campaign-banner-section.tsx`
- `components/sections/fabric-category-motion-grid.tsx`
- `lib/content/blocks/block-editor-schemas.ts`
- `lib/content/blocks/hero.tsx`
- `lib/content/blocks/image-text-split.tsx`
- `lib/content/blocks/newsletter-signup.tsx`
- `lib/content/blocks/story-editorial.tsx`
- `lib/content/blocks/trust-signals.tsx`
- `lighthouserc.cjs`
- `SEO_PHASE_2A_TEST_BASELINE_TRIAGE.md`
- `SEO_PHASE_2A_MOBILE_LCP_AUDIT.md`
- `SEO_PHASE_2A_ASSET_CONVERSION_APPROVAL_LIST.md`
- `SEO_INTERNAL_LINKING_AUDIT.md`
- `SEO_PHASE_2B_INTERNAL_LINKING_IMPLEMENTATION_PLAN.md`
- `SEO_IMAGE_ALT_APPROVAL_PACKET.md`
- `SEO_PHASE_2A_BASELINE_LCP_INTERNAL_LINKING_REPORT.md`

Pre-existing dirty/user-owned items were left alone unless listed above. Notably, `components/layout/site-header-nav.tsx`, `app/(site)/how-it-works/page.tsx`, and `app/(site)/how-it-works/how-it-works-experience.tsx` already had unrelated/user-owned changes.

## Safe Performance Fixes Implemented

- Header and our-story inline logo placements now use existing `public/Ftt_logo_navbar.png` instead of large `public/logo.png`.
- Below-fold fabric category images now use `fetchPriority="low"`.
- Below-fold campaign banner images now use `fetchPriority="low"`.
- LHCI public paths now audit canonical policy pages instead of legacy top-level policy URLs.

## Mobile LCP Findings

Route-specific mobile LHCI still fails the 2.5s LCP budget:

| Route | LCP | Main blocker |
|---|---:|---|
| `/` | 5.1s | Root/render delay plus early below-hero image work. |
| `/collection` | 4.6s | Collection hero image load delay. |
| `/our-story` | 4.4s | Cover image load delay. |
| `/how-it-works` | 5.4s | Text LCP render delay; user-owned dirty animated page. |
| `/packing` | 3.8s | Text LCP render delay. |
| `/policies/privacy-policy` | 4.0s | Text LCP render delay. |
| `/policies/terms-of-service` | 3.9s | Text LCP render delay. |
| `/policies/shipping-delivery-policy` | 3.8s | Text LCP render delay. |
| `/policies/return-refund-policy` | 4.3s | Text LCP render delay. |
| `/collection/midnight-chiffon-saree` | 5.7s | PDP gallery image load delay; product media/data approval required before image replacement. |

The PDP route also failed `color-contrast` and `heading-order` in the custom LHCI run. Those were not changed because they are outside this SEO Phase 2A scope and touch visible UI.

## Asset Conversion Approval List

Created `SEO_PHASE_2A_ASSET_CONVERSION_APPROVAL_LIST.md`. No large product/editorial/banner assets were replaced without approval.

## Internal Linking Audit

Created `SEO_INTERNAL_LINKING_AUDIT.md`.

Key findings:

- Footer and llms.txt use canonical policy routes.
- FAQ links to canonical policy routes.
- Query-filter URLs exist for useful collection UX, but should remain excluded from sitemap/index targets.
- `/why` and `/sell-your-saree` need more visible inbound links before broader indexing.
- The user-owned how-it-works experience currently links to `/sell`; confirm route ownership before changing it to `/sell-your-saree`.

## Internal Linking Implementation Plan

Created `SEO_PHASE_2B_INTERNAL_LINKING_IMPLEMENTATION_PLAN.md`.

Visible anchor text changes are marked approval-required.

## Image Alt Approval Packet

Created `SEO_IMAGE_ALT_APPROVAL_PACKET.md`.

No alt changes were implemented. Product alt text needs brand/content approval before Phase 2B or Phase 3 implementation.

## Command Results

| Command | Result |
|---|---|
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec vitest run tests/unit/block-hero.test.ts tests/unit/block-p308-new-blocks.test.ts tests/unit/blocks-trust-signals.test.ts tests/unit/homepage-blocks.test.ts --reporter=verbose` | Passed: 4 files, 181 tests. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec vitest run tests/unit/block-p308-new-blocks.test.ts tests/unit/blocks-trust-signals.test.ts --reporter=verbose` | Passed: 2 files, 141 tests. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run lint` | Passed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsc --noEmit --pretty false` | Passed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run build` | Passed. Build emitted the expected local warning: `[seo] Invalid production canonical origin "http://localhost:3000"; using https://www.fromthetrunk.shop.` |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run test` | Failed only `tests/unit/site-feedback-fixes.test.ts > Brand content - How It Works page > uses the 'second story' heading`. The assertion expects `Give your saree a second story`, but `app/(site)/how-it-works/page.tsx` is user-owned dirty content and was not changed. Overall result: 1 failed file/test, 128 passed files, 1647 passed tests. |
| SEO-focused follow-up test run | Passed: 10 files, 252 tests across SEO hardening, site origin, image optimization, JSON-LD/schema, and fixed block/homepage tests. |
| Route-specific mobile LHCI audit | Failed LCP budget on audited routes; reports written to `test-results/lighthouse/phase-2a-mobile/`. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run verify:ux` | Failed during the public mobile LHCI pass before desktop/admin passes. Reports written to `test-results/lighthouse/mobile/`. |

`verify:ux` public mobile assertion failures:

| Route | LCP found | Other assertion notes |
|---|---:|---|
| `/` | 7599.13ms | LCP budget failed. |
| `/collection` | 5193.07ms | LCP budget failed. |
| `/cart` | 4535.97ms | LCP budget failed; SEO score warning 0.66 below 0.85. This is a transactional noindex route, not a sitemap target. |
| `/checkout` | 4589.81ms | LCP budget failed; SEO score warning 0.66 below 0.85. This is a transactional noindex route, not a sitemap target. |
| `/our-story` | 4717.11ms | LCP budget failed. |
| `/how-it-works` | 5396.64ms | LCP budget failed; route has user-owned dirty content/experience changes and was not edited. |
| `/policies/privacy-policy` | 3989.81ms | LCP budget failed. |
| `/policies/terms-of-service` | 4134.58ms | LCP budget failed. |
| `/policies/shipping-delivery-policy` | 3986.11ms | LCP budget failed. |
| `/policies/return-refund-policy` | 3985.13ms | LCP budget failed. |
| `/packing` | 3839.38ms | LCP budget failed. |

## Remaining Blockers

- Mobile LCP remains above 2.5s on all audited public routes.
- `verify:ux` short-circuited on the public mobile LHCI failures, so desktop/admin LHCI passes did not run in that command.
- Text-route render delay needs a separate global performance pass.
- Product media/alt text needs approval before changes.
- Large legacy asset replacement needs visual approval.
- `/how-it-works` route is user-owned dirty work; ownership approval required before SEO/performance edits there.
- The full test suite has one remaining user-owned content assertion failure in `tests/unit/site-feedback-fixes.test.ts`.
- Production Search Console validation is pending.
- Do not submit sitemap until explicitly approved.

## GO / NO-GO

| Gate | Decision | Reason |
|---|---|---|
| Phase 2B internal linking implementation | GO with approval | The plan is ready, but visible anchor text and placements need content approval. |
| Search Console sitemap submission | NO-GO | User explicitly did not approve submission; mobile LCP and approval packets remain open. |
| Production indexing readiness | NO-GO | Mobile LCP, asset approval, product alt approval, and Search Console validation remain blockers. |
