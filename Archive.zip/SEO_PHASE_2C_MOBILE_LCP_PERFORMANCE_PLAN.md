# SEO Phase 2C Mobile LCP Performance Plan

Date: June 30, 2026

Scope: `/`, `/collection`, `/our-story`, `/how-it-works`, `/packing`, canonical policy pages, and one live PDP (`/collection/midnight-chiffon-saree`).

Source evidence: Phase 2A route-specific LHCI mobile audit plus Phase 2B/2C code inspection. No visual redesign, product media replacement, or user-owned `how-it-works` animation edits were made.

## Route Plan

| Route | Current mobile LCP | LCP element | Delay profile | Root document / TTFB | Font / render blocking | Script / hydration cost | First image priority | Safe fix | Approval-required fix | Classification |
|---|---:|---|---|---|---|---|---|---|---|---|
| `/` | 5.1s route-specific, 5.1s `verify:ux` | Lighthouse did not expose a stable node in Phase 2A route run. | Root/render delay plus early below-fold image work. | ~896ms in route run. | `next/font` uses `display: "swap"`; remaining issue appears render scheduling. | Homepage has client intro, hero carousel, campaign and landing sections. | True hero first slide has priority/high. | Phase 2A reduced logo source and set below-fold fabric/campaign images low priority. No extra safe Phase 2B change found. | Asset conversion for large fallback/category/editorial images after visual approval. | Improved versus prior `verify:ux`, still above budget. |
| `/collection` | 4.6s route-specific, 5.2s `verify:ux` | Collection hero image. | Image load delay dominated Phase 2A. | ~700-900ms local. | No font misconfiguration found. | Client carousel/filter UI contributes hydration. | First collection hero image priority/high; inactive slides mount after delay. | Kept only first hero image priority; no accidental extra preload found. | Deeper route/data render pass and approved image conversions for collection banners. | Still above budget. |
| `/our-story` | 4.4s route-specific, 4.5s `verify:ux` | Cover banner image. | Image load delay. | ~767ms route run. | No safe font change found. | Heavy client story/book animation. | Cover banner is priority. | Phase 2A logo asset reduction retained. | Animation/client bundle reduction needs visual QA; story asset conversion requires approval. | Still above budget. |
| `/how-it-works` | 5.4s route-specific, 5.4s `verify:ux` | Hero paragraph text. | Render delay dominated. | Local static route. | No safe font change found. | User-owned GSAP/framer client animation likely contributes. | No LCP image. | Not edited because route ownership is not confirmed and user forbade content changes. | Owner approval to optimize animation/hydration or split static shell from client animation. | Blocked by user-owned work. |
| `/packing` | 3.8s route-specific, 4.0s `verify:ux` | Body paragraph text. | Render delay dominated. | Local static route. | No safe font change found. | Minimal route JS; likely global render cost. | No LCP image. | No route-local image fix available. | Global CSS/font/script render-delay investigation. | Still above budget. |
| `/policies/privacy-policy` | 4.0s route-specific, 4.1s `verify:ux` | First policy body paragraph. | Render delay dominated. | ~939ms route run. | No safe font change found. | Minimal route JS; likely global render cost. | No LCP image. | Canonical policy route retained. | Global render-delay pass. | Still above budget. |
| `/policies/terms-of-service` | 3.9s route-specific, 4.0s `verify:ux` | First policy body paragraph. | Render delay dominated. | ~792ms route run. | No safe font change found. | Minimal route JS; likely global render cost. | No LCP image. | Canonical policy route retained. | Global render-delay pass. | Still above budget. |
| `/policies/shipping-delivery-policy` | 3.8s route-specific, 4.0s `verify:ux` | First policy body paragraph. | Render delay dominated. | ~746ms route run. | No safe font change found. | Minimal route JS; likely global render cost. | No LCP image. | Canonical policy route retained. | Global render-delay pass. | Still above budget. |
| `/policies/return-refund-policy` | 4.3s route-specific, 4.3s `verify:ux` | First policy body paragraph. | Render delay dominated. | ~935ms route run. | No safe font change found. | Minimal route JS; likely global render cost. | No LCP image. | Canonical policy route retained. | Global render-delay pass. | Still above budget. |
| `/collection/midnight-chiffon-saree` | 5.7s route-specific | PDP gallery main image. | Image load delay dominated. | ~847ms route run. | No safe font change found. | PDP gallery is client-side but only main image is priority. | Main gallery image has priority; thumbnails are decorative/lazy. | Phase 2B added alt text and support links only; no media/crop changes. | Product media cleanup or conversion requires approval because current image resolves to `collection_banner.png`. | Approval-required. |

## Implemented Safe LCP Work

- Retained Phase 2A logo source reduction and below-fold low-priority image hints.
- Confirmed homepage and collection true first images are the only intentional high-priority carousel images.
- Did not add new eager images while adding internal links.
- Kept PDP thumbnail images decorative and non-priority.

## Next Safe Investigation

- Split local LHCI by route with trace inspection for text-only route render delay.
- Measure shared layout, analytics, font CSS, and client components before changing route visuals.
- Audit `HomeIntroGate`, homepage client sections, and story/why animation bundles for hydration cost.
- Only after approval, create optimized asset variants and run visual diff checks before switching references.
