# Production SEO Audit

Date: 2026-07-01
Result: NO-GO until env and live validation complete

## What Is Working Locally

Code-level checks found:

- Shared metadata helper in `lib/seo/metadata.ts`.
- Canonical helper in `lib/seo/site-url.ts`.
- Product JSON-LD, Organization JSON-LD, WebSite JSON-LD, and Breadcrumb JSON-LD in `lib/seo/json-ld.ts`.
- Product SEO image filtering in `lib/seo/image-urls.ts`.
- Product image alt helpers in `lib/seo/image-alt.ts`.
- Dynamic sitemap in `app/sitemap.ts`.
- Robots rules in `app/robots.ts`.
- `llms.txt` route in `app/llms.txt/route.ts`.
- Cart, checkout, account, and search routes use noindex metadata.
- Filtered collection pages use noindex/follow.
- Legacy policy routes redirect to canonical policy URLs.

## Local SEO Findings

Local server with local env emitted localhost origins:

- canonical links
- Open Graph URL
- JSON-LD `url`
- sitemap `<loc>`
- robots sitemap URL
- `llms.txt` links

This is not acceptable for production or Search Console submission.

Controlled production env override emitted correct origins:

- `https://www.fromthetrunk.shop`

Conclusion: the code path supports production origins, but production env must be verified before push.

## Build Warning

`pnpm run build` passed but warned:

```text
[seo] Invalid production canonical origin "http://localhost:3000"; using https://www.fromthetrunk.shop.
```

This warning must not appear in final production verification.

## SEO Route Coverage

Sampled public routes returned 200 and emitted metadata:

- `/`
- `/collection`
- `/collection/stretchfit-blouse`
- `/our-story`
- `/our-team`
- `/how-it-works`
- `/packing`
- `/policies/*`
- `/faqs`
- `/why`
- `/sell-your-saree`
- `/guides/*`

Transactional/private routes are noindex:

- `/cart`
- `/checkout`
- `/account`
- `/search`

## Search Console / Sitemap Status

Not performed by this audit:

- no sitemap submission
- no indexing request
- no Search Console inspection
- no live production crawl
- no Google Image Search validation

These were intentionally skipped because the user requested audit-only and no production actions.

## Decision

NO-GO until:

- Production env is verified to emit `https://www.fromthetrunk.shop`.
- `pnpm-lock.yaml` is restored and all gates pass.
- Mobile LCP is resolved or explicitly accepted.
- Live sitemap, robots, canonical, and Search Console checks are completed after deploy approval.
