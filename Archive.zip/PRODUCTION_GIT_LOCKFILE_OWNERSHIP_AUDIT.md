# Production Git Lockfile Ownership Audit

Date: 2026-07-01
Result: NO-GO

## Commands

- `git status --short`: dirty tree with broad tracked modifications, deletions, and untracked files.
- `git diff --name-status`: confirmed tracked changes include application, checkout, auth, API, DB, SEO, assets, tests, and config surfaces.
- `git diff --check`: passed.
- `git ls-files pnpm-lock.yaml`: `pnpm-lock.yaml` is tracked.
- `test -f pnpm-lock.yaml`: `pnpm-lock.yaml` is missing.

## Lockfile Status

`pnpm-lock.yaml` is tracked by git but currently deleted from the working tree.

Impact:

- Reproducible dependency installation is not guaranteed.
- `pnpm audit` cannot run.
- Production deploy dependency resolution can drift.

Evidence:

```text
pnpm-lock.yaml
D	pnpm-lock.yaml
pnpm-lock missing
```

## Dirty Tree Ownership Risk

The current worktree contains many unrelated or cross-cutting changes, including:

- `app/(site)/checkout/*`
- `api/hono/routes/payments.ts`
- `api/hono/routes/webhooks.ts`
- `api/hono/routes/orders.ts`
- `db/schema.ts`
- `db/queries/*`
- `drizzle/0024_order_item_selected_options.sql`
- `drizzle/0025_payment_hardening.sql`
- SEO, media, layout, product, cart, and test files.

This audit cannot claim production ownership for these changes. Production push needs owner approval for the dirty tree, especially payment, auth, checkout, DB, and migration surfaces.

## Ignored Report Files

`.gitignore` ignores root generated reports such as:

- `/*_AUDIT.md`
- `/*_REPORT.md`
- `/SEO_*.md`

That means most generated audit reports are intentionally not staged unless the team changes ignore rules.

## Decision

NO-GO until:

- `pnpm-lock.yaml` is restored or the lockfile deletion is explicitly approved and replaced with a documented package-manager policy.
- Dirty-tree ownership is reviewed file-by-file.
- Payment, auth, checkout, DB, and migration changes are explicitly approved by their owner.
