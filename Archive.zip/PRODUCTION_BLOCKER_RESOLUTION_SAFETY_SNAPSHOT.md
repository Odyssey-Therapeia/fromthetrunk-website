# FTT Production Blocker Resolution Safety Snapshot

Date: 2026-07-01
Scope: production blocker resolution sprint

## Commands Run Before Any Fix

- `git status --short`
- `git diff --name-status`
- `git diff --check`
- `git ls-files pnpm-lock.yaml`
- `ls -l pnpm-lock.yaml`
- `git diff -- package.json`
- `git status --ignored --short`
- `git diff --stat`
- `git status --short package.json pnpm-lock.yaml package-lock.json bun.lockb bun.lock`
- `git diff --name-only`
- `git ls-files -d`

## Safety State

- `git diff --check`: passed with no whitespace errors.
- `package.json`: no local diff.
- `pnpm-lock.yaml`: tracked by Git and deleted from the working tree.
- Other package manager locks checked: no changed `package-lock.json`, `bun.lockb`, or `bun.lock` surfaced in the targeted status check.
- Dependency changes intentional: not evidenced locally; `package.json` is unchanged.
- Safe automated change approved by the sprint brief: restore only the tracked `pnpm-lock.yaml`.
- Not safe to change without explicit approval: auth, OTP, checkout, payment/Razorpay, cart reservation, shipping/payment math, order ownership, wishlist ownership, product pricing/stock/availability, database schema, migrations, production data, live media replacement, public copy, and route/functionality changes.

## Dirty And Untracked State Summary

The working tree is already broad and user-owned. High-risk modified areas include:

- API and commerce routes: `api/hono/routes/orders.ts`, `api/hono/routes/payments.ts`, `api/hono/routes/products.ts`, `api/hono/routes/webhooks.ts`, `app/api/v2/[...route]/route.ts`.
- Checkout, cart, account, and receipt surfaces: `app/(site)/cart/page.tsx`, `app/(site)/checkout/page.tsx`, checkout confirmation files, `components/cart/*`, `components/checkout/*`, account order pages.
- Payment/order internals: `lib/checkout/use-checkout-payment.ts`, `lib/orders/complete-paid-order.ts`, `lib/orders/receipt-html.ts`, `lib/payments/razorpay.ts`, `lib/store/cart-store.ts`.
- Database/schema/migration-adjacent work: `db/schema.ts`, `db/queries/orders.ts`, `db/queries/products.ts`, untracked `drizzle/0024_order_item_selected_options.sql`, untracked `drizzle/0025_payment_hardening.sql`.
- Public media deletion/replacement candidates: deleted tracked `public/banner/banner1.png`, `public/banner/banner2.gif`, `public/banner/banner3.png`, `public/banner/banner4.png`; untracked AVIF/WebM/poster media and public media folders.
- SEO/report work: untracked visible production reports, ignored prior production/SEO reports, modified `app/sitemap.ts`, `app/llms.txt/route.ts`, `lib/seo/json-ld.ts`, and untracked SEO helpers.

## Ignored Report And Artifact Files

`git status --ignored --short` shows ignored production/SEO audit reports, `.next/`, `.lighthouseci/`, `node_modules/`, `test-results/`, `.env.local`, `next-env.d.ts`, and `tsconfig.tsbuildinfo`.

## Deleted Tracked Files

- `app/api/chat/route.ts`
- `app/api/csp-report/route.ts`
- `app/api/debug/db-ping/route.ts`
- `app/api/latest-reel/route.ts`
- `app/api/v2/geo/reverse/route.ts`
- `app/api/v2/geo/search/route.ts`
- `pnpm-lock.yaml`
- `public/banner/banner1.png`
- `public/banner/banner2.gif`
- `public/banner/banner3.png`
- `public/banner/banner4.png`

## Decision

Proceed only with restoring `pnpm-lock.yaml` from Git because the lockfile is tracked, deleted, and `package.json` has no diff. All other dirty files remain untouched unless later changes are proven safe, non-visual, and inside the blocker sprint boundaries.
