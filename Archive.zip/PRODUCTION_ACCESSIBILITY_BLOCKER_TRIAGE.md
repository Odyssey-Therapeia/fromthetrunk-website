# FTT Production Accessibility Blocker Triage

Date: 2026-07-01

## Initial Sampled Findings

Focused axe checks found issues on sampled mobile pages:

- `/our-story`: unnamed progressbar.
- `/our-story` and `/collection`: duplicate or nested `main` landmarks because route pages used their own `main` inside the shared site layout `main`.
- Shared header logo: redundant image alt text inside a link that already has an `sr-only` accessible name.

## Fixes Applied

- Added `aria-label="Story progress"` to the progress indicator.
- Changed route-local wrapper landmarks from `main` to `div` in `/our-story` and `/collection`.
- Marked the header logo image decorative with `alt=""` while keeping the existing screen-reader link label.

## Post-Fix Focused Verification

Focused axe sampling returned 0 violations on:

- `/`
- `/collection`
- `/our-story`
- `/policies/privacy-policy`

## Limits

This is not a full authenticated admin accessibility certification. The required `agent:check` stopped at public mobile LCP failure before reaching the later LHCI matrix stages.
