# Production Performance CWV Audit

Date: 2026-07-01
Result: NO-GO

## Required Gates

`lighthouserc.cjs` enforces:

- mobile LCP <= 2500 ms
- CLS <= 0.1
- performance score >= 0.7
- accessibility score >= 0.9
- SEO warning threshold >= 0.85 for public scope

## Command Results

Failed:

- `pnpm run verify:ux`
- `pnpm run agent:check`

Both failed on public mobile LCP assertions.

## Latest `agent:check` Public Mobile LCP Failures

| Route | LCP found | Budget |
| --- | ---: | ---: |
| `/` | 5120.14495 ms | 2500 ms |
| `/collection` | 5723.5365 ms | 2500 ms |
| `/cart` | 4619.4995 ms | 2500 ms |
| `/checkout` | 4742.221875 ms | 2500 ms |
| `/our-story` | 4666.69195 ms | 2500 ms |
| `/how-it-works` | 5575.690125 ms | 2500 ms |
| `/policies/privacy-policy` | 4065.4095 ms | 2500 ms |
| `/policies/terms-of-service` | 4145.384 ms | 2500 ms |
| `/policies/shipping-delivery-policy` | 4141.66525 ms | 2500 ms |
| `/policies/return-refund-policy` | 4066.069 ms | 2500 ms |
| `/packing` | 4292.682 ms | 2500 ms |

Cart and checkout also produced Lighthouse SEO warnings because they are intentionally noindex transactional routes.

## Visual Timing Smoke

Playwright visual pass showed route load/check times around 6 to 8 seconds for sampled pages. This is not a CWV substitute, but it aligns with the Lighthouse LCP concern.

## Asset Contributors

Large assets present include:

- `public/Welcoming.mp4` around 13 MB
- `public/hero/banner.png` around 11 MB
- `public/hero/timeless.JPG` around 7.5 MB
- `public/welcome.webp` around 6.8 MB
- `public/Ftt_logo_navbar.svg` around 4.9 MB
- several packaging, hero, banner, and category images above 1 MB

Optimized candidates exist under `public/seo-candidates/`, but media swaps need approval.

## Decision

NO-GO until:

- mobile public LCP passes the 2500 ms gate, or
- the owner explicitly accepts this production risk with a dated exception.
