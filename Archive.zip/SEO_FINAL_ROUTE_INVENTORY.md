# Final Route Inventory

Date: 2026-07-01

| Route | Status | Canonical | Sitemap | Robots | LLMS | Schema | Internal Link Coverage |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `/` | indexable | `https://www.fromthetrunk.shop/` | yes | allowed | yes | Organization/WebSite | high |
| `/collection` | indexable | `https://www.fromthetrunk.shop/collection` | yes | allowed | yes | page/product listings | high |
| `/collection/[slug]` | indexable if public/non-sold | product canonical | yes when public/non-sold | allowed | yes for listed products | Product/BreadcrumbList | high |
| `/our-story` | indexable | `/our-story` | yes | allowed | yes | page metadata | high |
| `/our-team` | indexable | `/our-team` | yes | allowed | yes | page metadata | medium |
| `/how-it-works` | indexable | `/how-it-works` | yes | allowed | yes | page metadata | high |
| `/packing` | indexable/support | `/packing` | yes | allowed | no | page metadata | medium |
| `/policies` | indexable | `/policies` | yes | allowed | yes | page metadata | high |
| `/policies/[slug]` | indexable | `/policies/[slug]` | yes | allowed | selected canonical policies in llms | page metadata | high |
| `/faqs` | indexable | `/faqs` | yes | allowed | yes | FAQPage | high |
| `/why` | indexable | `/why` | yes | allowed | yes | page metadata | medium |
| `/sell-your-saree` | indexable | `/sell-your-saree` | yes | allowed | yes | keyword guide/FAQ/breadcrumb | medium |
| `/guides/what-is-a-pre-loved-saree` | indexable | guide canonical | yes | allowed | yes | guide/FAQ/breadcrumb | medium |
| `/guides/pre-loved-vs-second-hand-saree` | indexable | guide canonical | yes | allowed | yes | guide/FAQ/breadcrumb | medium |
| `/collection/fabric/silk` | indexable when product threshold met | fabric canonical | yes | allowed | no | keyword/product page schema | medium |
| `/collection/occasion/festive` | indexable when product threshold met | occasion canonical | yes | allowed | no | keyword/product page schema | medium |
| `/cart` | noindex transactional | none | no | disallowed | no | none | not SEO target |
| `/checkout` | noindex transactional | none | no | disallowed | no | none | not SEO target |
| `/account/**` | noindex private | none | no | disallowed | no | none | not SEO target |
| `/search` | noindex utility | none | no | disallowed | no | none | not SEO target |
| `/admin/**` | noindex private | none | no | disallowed | no | none | not SEO target |
| `/api/**` | system | none | no | disallowed | no | none | not SEO target |
| `/privacy-policy` | redirect | `/policies/privacy-policy` | no | allowed redirect | no | none | legacy |
| `/terms-of-service` | redirect | `/policies/terms-of-service` | no | allowed redirect | no | none | legacy |
| `/shipping-policy` | redirect | `/policies/shipping-delivery-policy` | no | allowed redirect | no | none | legacy |
| `/return-policy` | redirect | `/policies/return-refund-policy` | no | allowed redirect | no | none | legacy |
| `/founders` | redirect | `/our-team` | no | allowed redirect | no | none | legacy |

