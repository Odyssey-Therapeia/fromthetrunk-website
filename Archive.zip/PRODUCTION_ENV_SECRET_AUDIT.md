# Production Env Secret Audit

Date: 2026-07-01
Result: NO-GO until production env is verified

No secret values were printed or copied in this audit.

## Production Example Keys

`.env.production.example` declares:

- `ADMIN_API_SECRET`
- `AZURE_AD_CLIENT_ID`
- `AZURE_AD_CLIENT_SECRET`
- `AZURE_AD_TENANT_ID`
- `CRON_SECRET`
- `DATABASE_URL`
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `NEXTAUTH_SECRET`
- `NEXTAUTH_URL`
- `NEXT_PUBLIC_ELECTRIC_SHAPE_URL`
- `NEXT_PUBLIC_RAZORPAY_KEY_ID`
- `NEXT_PUBLIC_SERVER_URL`
- `OPENAI_API_KEY`
- `OPENAI_EMBEDDING_MODEL`
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`
- `RESEND_API_KEY`
- `RESEND_FROM_EMAIL`
- `SITE_URL`
- `TWITTER_CLIENT_ID`
- `TWITTER_CLIENT_SECRET`

## Local Env Key Names Observed

`.env.local` key names include:

- auth and OTP secrets
- database URL
- GA4 keys
- KV/Redis keys
- NextAuth URL/secret
- Razorpay keys
- Resend keys
- order/reservation/preview token secrets
- social feed keys

Missing locally compared with the production readiness script:

- `CRON_SECRET`
- `ADMIN_API_SECRET`
- complete OAuth provider pair

## Readiness Script Result

`scripts/demo-readiness.ts` run with `.env.local` loaded via temporary `npx tsx`:

- `DATABASE_URL`: set
- `NEXTAUTH_SECRET`: set
- `NEXTAUTH_URL`: set
- `NEXT_PUBLIC_SERVER_URL`: set
- `RAZORPAY_*`: set
- `RESEND_*`: set
- `CRON_SECRET`: missing
- `ADMIN_API_SECRET`: missing
- OAuth provider pair: missing
- Auth/public URL alignment: failed
- Published products seeded: 57 published products found

Summary:

```text
Demo readiness summary: FAIL (4 failing checks)
```

## Canonical Origin Check

With the local server using local env, rendered pages and machine-readable files emitted `http://localhost:3000` origins.

With controlled production env overrides on a separate local port:

- `SITE_URL=https://www.fromthetrunk.shop`
- `NEXT_PUBLIC_SERVER_URL=https://www.fromthetrunk.shop`
- `NEXTAUTH_URL=https://www.fromthetrunk.shop`

The site emitted production origins for:

- canonical links
- Open Graph URL
- Organization JSON-LD
- sitemap URLs
- robots sitemap URL
- `llms.txt` links

Conclusion: the code can emit production origins, but production env must be verified before any production push or sitemap submission.

## Required Production Env Checks

Before deployment:

- Confirm `SITE_URL=https://www.fromthetrunk.shop`.
- Confirm `NEXT_PUBLIC_SERVER_URL=https://www.fromthetrunk.shop`.
- Confirm `NEXTAUTH_URL=https://www.fromthetrunk.shop`.
- Confirm `NEXTAUTH_SECRET` is production-grade and not shared with local/dev.
- Confirm `CRON_SECRET` exists before enabling cron routes.
- Confirm `ADMIN_API_SECRET` exists before admin secret fallback is used.
- Confirm `RAZORPAY_KEY_ID` and `NEXT_PUBLIC_RAZORPAY_KEY_ID` are both live-mode and match the same account.
- Confirm `RAZORPAY_WEBHOOK_SECRET` matches the live webhook endpoint.
- Confirm `RESEND_API_KEY` and sender domain are production-approved.
- Confirm API docs are not exposed unless deliberately enabled.

## Decision

NO-GO until production env values are verified in Vercel or the production deployment target.
