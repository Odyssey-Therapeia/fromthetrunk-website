# Production Legal Privacy Tracking Audit

Date: 2026-07-01
Result: CONDITIONAL NO-GO

## Legal Routes

Sampled legal routes returned 200:

- `/policies`
- `/policies/privacy-policy`
- `/policies/terms-of-service`
- `/policies/shipping-delivery-policy`
- `/policies/return-refund-policy`

Legacy redirects were present:

- `/privacy-policy` -> `/policies/privacy-policy`
- `/terms-of-service` -> `/policies/terms-of-service`
- `/shipping-policy` -> `/policies/shipping-delivery-policy`
- `/return-policy` -> `/policies/return-refund-policy`

## Private / Transactional Indexing

Noindex observed:

- `/cart`
- `/checkout`
- `/account`
- `/search`

Robots disallows:

- `/admin/`
- `/account/`
- `/api/`
- `/api/debug/`
- `/api/v2/docs`
- `/api/v2/openapi.json`
- `/cart`
- `/checkout`
- `/search`
- `/wishlist`

## Tracking

Observed:

- Vercel Analytics in site layout.
- Speed Insights in site layout.
- GTM is gated by `NEXT_PUBLIC_GTM_ID`.
- GA4 server events are gated by `GA4_MEASUREMENT_ID` and `GA4_API_SECRET`.
- Meta CAPI is env-gated.

## Privacy Risks

- Local API docs are exposed; production must confirm they are disabled or approved.
- Tracking live behavior was not validated against production consent/legal requirements.
- No cookie banner/CMP validation was performed in this audit.
- No live analytics request inspection was performed.

## Decision

NO-GO until:

- production tracking IDs and consent/legal posture are approved,
- production API docs exposure is verified,
- privacy/legal owner signs off policy pages and tracking setup.
