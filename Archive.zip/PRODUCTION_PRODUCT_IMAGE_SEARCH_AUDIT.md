# Production Product Image Search Audit

Date: 2026-07-01
Result: CONDITIONAL NO-GO

## Code-Level Image SEO

Observed implementation:

- `productSeoImageUrls(product)` derives HTTPS-safe image URLs.
- `toSeoImageUrl()` rejects localhost, `127.0.0.1`, non-HTTPS, and `.vercel.app` image origins.
- PDP metadata uses the first product image when it passes SEO URL validation.
- Product JSON-LD includes image URLs when available.
- Product sitemap entries include image URLs when available.
- Product cards and PDP gallery use SEO alt helper functions.

## Visual and Accessibility Evidence

Playwright sampled pages:

- `/`
- `/collection`
- `/collection/stretchfit-blouse`
- `/our-story`
- `/policies/privacy-policy`
- `/checkout`

Across mobile and desktop:

- missing image alt count: 0
- missing button accessible name count: 0
- horizontal overflow: false

## Image Search Limitations

This audit did not perform:

- live Google Image Search checks
- Search Console image indexing checks
- Merchant Center image diagnostics
- production CDN image crawl

Those require live production validation after deploy approval.

## Media Replacement Boundary

The user explicitly prohibited unapproved product media/crop/color changes. This audit did not:

- replace product images
- recrop product images
- alter colors
- delete assets
- submit image sitemap

## Risks

- Large image/video assets remain a Core Web Vitals risk.
- `public/seo-candidates/` contains optimized candidates, but swapping them into live routes requires explicit visual approval.
- Local SEO origin must be production URL before image sitemap/Search Console work.

## Decision

Code-level image SEO is close, but production image search remains NO-GO until:

- production URL env is verified,
- LCP/media risk is resolved or accepted,
- live Search Console and image checks are completed.
