# FTT Production High-Risk Dirty Tree Triage

Date: 2026-07-01

## Scope

This triage documents the existing dirty working tree before production-blocker decisions. It is intentionally evidence-only and does not approve the high-risk changes for production.

## Summary

- The working tree contains broad pre-existing/user-owned changes.
- I did not revert, rewrite, or normalize those changes.
- I did not edit checkout, payment, auth, OTP, Razorpay, cart reservation, shipping math, order ownership, wishlist ownership, product pricing, stock, availability, database schema, migrations, production data, or live media assets.
- Safe code edits made during this sprint were limited to semantic/a11y wrappers, decorative logo alt text, and one image fetch priority hint.

## High-Risk Areas

| Area | Files observed dirty or untracked | Production risk | Action taken |
| --- | --- | --- | --- |
| API and commerce routes | `api/hono/routes/orders.ts`, `payments.ts`, `products.ts`, `webhooks.ts`, schemas, `api/hono/app.ts`, `api/hono/site-app.ts`, `app/api/v2/[...route]/route.ts` | Business behavior, payment callbacks, order state, product data | Read-only triage only |
| Deleted and migrated API routes | deleted `app/api/chat/route.ts`, `app/api/csp-report/route.ts`, `app/api/debug/db-ping/route.ts`, `app/api/latest-reel/route.ts`, deleted geo routes, untracked `api/hono/routes/*.ts` | Route availability and observability | Read-only triage only |
| Checkout, cart, and account flows | `app/(site)/cart/page.tsx`, `app/(site)/checkout/page.tsx`, checkout confirmation files, `components/cart/*`, `components/checkout/*`, account order pages | Purchase path and customer order visibility | Read-only triage only |
| Payment/order internals | `lib/checkout/use-checkout-payment.ts`, `lib/orders/complete-paid-order.ts`, `lib/orders/receipt-html.ts`, `lib/payments/razorpay.ts`, `lib/store/cart-store.ts` | Payment capture, receipts, order consistency | Read-only triage only |
| Database and migrations | `db/schema.ts`, `db/queries/orders.ts`, `db/queries/products.ts`, untracked `drizzle/0024_order_item_selected_options.sql`, `drizzle/0025_payment_hardening.sql` | Data compatibility and migration safety | Read-only triage only |
| Product/media changes | product cards/gallery, blouse controls, product type helpers, deleted tracked banner PNG/GIF files, untracked AVIF/WebM/poster assets | Product presentation, stock/type filtering, asset availability | Read-only triage only |
| SEO and route metadata | `app/sitemap.ts`, `app/llms.txt/route.ts`, `lib/seo/*`, production reports | Crawl/indexing behavior | Verified current generated outputs only |
| Tests | payment, webhook, order, customer, SEO, migrated-route tests | Test expectations may reflect unreviewed behavior | Ran tests; did not alter restricted tests |

## Production Decision

The dirty tree is not production-clean. Any production push still needs owner review for the high-risk commerce/auth/payment/schema/media route areas above. My safe fixes do not validate those broader user-owned changes for production.
