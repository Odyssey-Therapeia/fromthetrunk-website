# Sitemap, Robots, LLMS, And Route Registry Recheck

Date: 2026-07-01

## Local Built Endpoint Results

- `/robots.txt`: 200, points to `https://www.fromthetrunk.shop/sitemap.xml`.
- `/sitemap.xml`: 200, emits production canonical URLs.
- `/llms.txt`: 200, emits production canonical key pages and product links.

## Sitemap Includes

- `/`
- `/collection`
- Public non-sold product pages
- `/our-story`
- `/our-team`
- `/faqs`
- `/how-it-works`
- `/policies`
- `/policies/[slug]`
- `/why`
- `/packing`
- `/collection/fabric/silk`
- `/collection/occasion/festive`
- `/sell-your-saree`
- Approved guide pages

## Sitemap Excludes

- Legacy top-level policy URLs.
- `/cart`
- `/checkout`
- `/account`
- `/search`
- `/admin`
- `/api`
- `/wishlist`
- Query-filter URLs.
- Sold/draft/private products.
- Deferred keyword pages whose product count/sitemap rules are not met.

## Robots

Robots disallows private/system routes and does not block public SEO pages, public assets, product image paths, or `/_next/image`.

## LLMS

`llms.txt` aligns with the canonical public route map and includes key product links from the current product query.

## Notes

Footer/header link coverage depends partly on active menu data. Recheck production CMS/menu output before final sitemap submission.

