# FTT Production Mobile LCP Blocker Plan

Date: 2026-07-01

## Gate

`lighthouserc.cjs` enforces `largest-contentful-paint <= 2500ms` as an error. The public mobile LHCI matrix still fails this budget.

## Final `agent:check` Public Mobile LCP Results

| Route | LCP | Status |
| --- | ---: | --- |
| `/` | 5198.64ms | Fail |
| `/collection` | 5420.57ms | Fail |
| `/cart` | 4697.66ms | Fail |
| `/checkout` | 4739.25ms | Fail |
| `/our-story` | 4968.21ms | Fail |
| `/how-it-works` | 5500.39ms | Fail |
| `/policies/privacy-policy` | 4140.60ms | Fail |
| `/policies/terms-of-service` | 4140.85ms | Fail |
| `/policies/shipping-delivery-policy` | 4293.24ms | Fail |
| `/policies/return-refund-policy` | 4366.73ms | Fail |
| `/packing` | 4062.63ms | Fail |

## Route Classification

| Route group | Routes | Sprint handling |
| --- | --- | --- |
| Public SEO pages | `/`, `/collection`, `/our-story`, `/how-it-works`, policy pages, `/packing` | Safe non-content fixes only |
| Transactional/noindex pages | `/cart`, `/checkout` | No functional SEO change; warnings are expected from noindex behavior |
| Approval-sensitive page | `/how-it-works` | No content, layout, or media rewrite without approval |

## Findings

- `/our-story` image discovery is now correctly hinted with `fetchPriority="high"`.
- The focused `/our-story` rerun still measured LCP above budget after the hint, so the remaining issue is broader than a missing fetch priority attribute.
- Several failing routes have text or route-render timing as the LCP bottleneck, not a simple image discovery issue.
- Fixing the remaining budget likely requires approval for route-level rendering, media, or design/layout decisions beyond the safe no-content sprint boundary.

## Next Approved Step Needed

Owner decision is required before changing visible page composition, replacing media, deleting assets, changing route content, or modifying checkout/cart route behavior.
