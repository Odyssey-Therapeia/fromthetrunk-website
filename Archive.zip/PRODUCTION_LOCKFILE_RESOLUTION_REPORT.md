# FTT Production Lockfile Resolution Report

Date: 2026-07-01

## Initial Finding

- `pnpm-lock.yaml` was tracked by Git.
- `pnpm-lock.yaml` was deleted from the working tree.
- `package.json` had no local diff.
- No other package manager lock drift was detected in the targeted lockfile status check.

## Resolution

Because `package.json` had no intentional dependency change, the lockfile was restored from Git:

```bash
git restore pnpm-lock.yaml
```

No dependencies were updated and the lockfile was not regenerated.

## Post-Restore Verification

- `git status --short package.json pnpm-lock.yaml`: no output.
- `ls -l pnpm-lock.yaml`: file exists, size `394555` bytes.
- `git diff -- pnpm-lock.yaml`: no output.

## Command Results

| Command | Result | Notes |
| --- | --- | --- |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm audit` | Pass | No known vulnerabilities found. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run lint` | Pass | `eslint .` completed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsc --noEmit --pretty false` | Pass | No TypeScript errors. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run build` | Pass | Build completed. Local `.env.local` canonical warnings fell back to `https://www.fromthetrunk.shop`. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run test` | Pass | 134 test files and 1679 tests passed. Non-fatal test logs were emitted by error-path tests. |

## Production Status

The missing tracked lockfile blocker is resolved. Remaining production status depends on the later LCP, accessibility, env, API exposure, dirty-tree, and final `verify:ux` / `agent:check` gates.
