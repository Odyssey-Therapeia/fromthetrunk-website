# SEO Phase 2B + 2C Internal Linking, Alt, And LCP Report

Date: June 30, 2026

## Files Changed

- `app/(site)/collection/[slug]/page.tsx`
- `app/(site)/policies/[slug]/page.tsx`
- `components/layout/site-footer.tsx`
- `components/product/product-card.tsx`
- `components/product/product-gallery.tsx`
- `components/sections/our-why-experience.tsx`
- `lib/content/nav-menu.ts`
- `lib/seo/image-alt.ts`
- `tests/e2e/site-feedback-fixes.spec.ts`
- `tests/unit/site-feedback-fixes.test.ts`
- `tests/unit/seo-phase-2b-2c.test.ts`
- `SEO_PHASE_2C_MOBILE_LCP_PERFORMANCE_PLAN.md`
- `SEO_PHASE_2C_ASSET_CONVERSION_RESULTS.md`
- `SEO_PHASE_2B_2C_INTERNAL_LINKING_ALT_LCP_REPORT.md`

Existing dirty files outside this phase remain user-owned or from prior SEO phases unless listed above.

## Internal Links Added

Canonical URLs only:

- PDP support block: `/how-it-works`, `/packing`, `/policies/shipping-delivery-policy`, `/policies/return-refund-policy`.
- Policy detail pages: `/faqs` plus related `/policies/[slug]` links from the legal policy source of truth.
- Why page: existing `Read the Story` visible label now points to `/our-story`; proof-point cards link to `/our-story` and `/how-it-works`.
- Fallback footer/header data: fallback header `Our Story` now points to `/our-story`; fallback footer includes `/collection`, `/our-story`, `/why`, `/how-it-works`, `/faqs`, `/sell-your-saree`, `/packing`, `/our-team`, and canonical policy routes.

## Anchor Text Used

- Existing visible labels preserved where possible: `Read the Story`, `Image led`, `Trust led`.
- New approved minimal anchors: `How It Works`, `Packing`, `Shipping`, `Returns`, `FAQs`.
- Policy cross-links use existing legal policy titles from `lib/legal/policies.ts`.
- No query-filter URLs, cart, checkout, account, search, admin, API, localhost, or preview URLs were added as SEO targets.

## Product Trust / Support Block

Status: implemented on PDPs.

Placement: directly below the existing PDP trust lines, without changing pricing, stock, cart, checkout, wishlist, or ownership logic.

## Policy Cross-Link Status

Status: implemented.

Policy detail pages now expose a crawlable FAQ link and related canonical policy links. Legacy top-level policy URLs remain excluded.

## Image Alt Changes

Implemented safe product alt helpers only:

- Product card: `[Product name], pre-loved [explicit fabric if present] saree from From the Trunk`.
- PDP main image: `[Product name] shown as a pre-loved saree[, explicit fabric if present]`.
- PDP gallery: first image uses PDP main alt; later images use `[Product name] detail view N`.
- PDP thumbnails remain `alt=""` because the thumbnail buttons already provide accessible labels and the images duplicate the main gallery.

No product color, crop, provenance, rating, review, or unverified detail was invented.

## How It Works Test Decision

Decision: update the test expectation only.

Reason: `app/(site)/how-it-works/page.tsx` and `app/(site)/how-it-works/how-it-works-experience.tsx` are user-owned dirty work, and the user explicitly said not to change page content. The source now intentionally contains `A second life, handled with care`, so the unit and E2E source/page assertions were aligned to that current content.

## LCP Fixes Implemented

- No new image preloads or eager non-LCP images were added.
- Existing Phase 2A low-priority image hints and logo source reduction were preserved.
- PDP thumbnail images were kept decorative/non-priority.
- No user-owned `how-it-works` animation or content was changed.

See `SEO_PHASE_2C_MOBILE_LCP_PERFORMANCE_PLAN.md` for route-level blockers and next actions.

## Asset Conversion Candidates / Results

See `SEO_PHASE_2C_ASSET_CONVERSION_RESULTS.md`.

No source asset was replaced and no code reference was changed because visual media replacement has not been approved.

## Tests Added / Updated

- Added `tests/unit/seo-phase-2b-2c.test.ts`.
- Updated How It Works expectations in `tests/unit/site-feedback-fixes.test.ts`.
- Updated the matching E2E expectation in `tests/e2e/site-feedback-fixes.spec.ts`.

Coverage added:

- Important fallback public links.
- PDP trust/support links.
- FAQ and policy canonical cross-links.
- No private/query/local/preview SEO targets in fallback SEO links.
- Product alt text patterns and decorative empty alt behavior.
- No fake review/rating schema.
- Sitemap source still excludes sold/draft/private/query routes.

## Command Results

| Command | Result |
|---|---|
| Focused SEO/How It Works tests | Passed: 4 files, 58 tests. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run lint` | Passed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsc --noEmit --pretty false` | Passed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run build` | Passed. Build emitted the expected local warning: `[seo] Invalid production canonical origin "http://localhost:3000"; using https://www.fromthetrunk.shop.` |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run test` | Passed: 130 files, 1659 tests. Console included expected non-fatal error-path logs from existing tests. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run verify:ux` | Failed during public mobile LHCI before desktop/admin passes. Reports written to `test-results/lighthouse/mobile/`. |

`verify:ux` public mobile assertions:

| Route | LCP found | Other assertion notes |
|---|---:|---|
| `/` | 5113.23ms | LCP budget failed; improved versus prior 7599.13ms `verify:ux` run, still above 2500ms. |
| `/collection` | 5191.01ms | LCP budget failed. |
| `/cart` | 4534.38ms | LCP budget failed; SEO score warning 0.66 below 0.85. Transactional noindex route, not a sitemap target. |
| `/checkout` | 4590.79ms | LCP budget failed; SEO score warning 0.66 below 0.85. Transactional noindex route, not a sitemap target. |
| `/our-story` | 4452.35ms | LCP budget failed. |
| `/how-it-works` | 5399.55ms | LCP budget failed; user-owned route content/animation not edited. |
| `/policies/privacy-policy` | 4143.39ms | LCP budget failed. |
| `/policies/terms-of-service` | 3987.02ms | LCP budget failed. |
| `/policies/shipping-delivery-policy` | 3984.75ms | LCP budget failed. |
| `/policies/return-refund-policy` | 4286.08ms | LCP budget failed. |
| `/packing` | 3985.77ms | LCP budget failed. |

## Remaining Blockers

- Mobile LCP remains above the 2.5s budget from Phase 2A evidence.
- `verify:ux` still short-circuits on public mobile LHCI failures, so desktop/admin LHCI passes did not run.
- `/how-it-works` performance work is blocked by user-owned route work unless ownership is approved.
- Product/media asset conversion remains approval-required.
- Production Search Console validation is pending.
- Sitemap submission is not approved.
- Existing unrelated dirty state, including the pre-existing `pnpm-lock.yaml` deletion, remains unresolved outside this phase.

## GO / NO-GO

| Gate | Decision | Reason |
|---|---|---|
| Search Console sitemap submission | NO-GO | User explicitly did not approve submission; mobile LCP and production validation remain open. |
| Production indexing readiness | NO-GO | Internal links and alt text improved, but mobile LCP, asset approvals, and production validation remain blockers. |
| Phase 2C performance implementation | GO with approval | Route-level plan is ready; visual asset swaps and user-owned animation changes need approval. |
