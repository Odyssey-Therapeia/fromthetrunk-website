# FTT Production Blocker Resolution Command Results

Date: 2026-07-01

## Commands

| Command | Result | Notes |
| --- | --- | --- |
| `git diff --check` | Pass | No whitespace errors. |
| `git restore pnpm-lock.yaml` | Pass | Restored tracked deleted lockfile because `package.json` had no diff. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm audit` | Pass | No known vulnerabilities found. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsc --noEmit --pretty false` | Pass | No TypeScript errors. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run lint` | Pass | ESLint completed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run build` | Pass | Build completed; local SEO origin warnings fell back to production canonical host. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run test` | Pass | 134 test files and 1679 tests passed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run verify:ux` | Fail | Public mobile LCP failed across the route set. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run agent:check` | Fail | Tests, lint, and build passed; public mobile LHCI failed LCP across 11 URLs. |

## Final `agent:check` Failure Numbers

| Route | LCP budget | Found |
| --- | ---: | ---: |
| `/` | 2500ms | 5198.64ms |
| `/collection` | 2500ms | 5420.57ms |
| `/cart` | 2500ms | 4697.66ms |
| `/checkout` | 2500ms | 4739.25ms |
| `/our-story` | 2500ms | 4968.21ms |
| `/how-it-works` | 2500ms | 5500.39ms |
| `/policies/privacy-policy` | 2500ms | 4140.60ms |
| `/policies/terms-of-service` | 2500ms | 4140.85ms |
| `/policies/shipping-delivery-policy` | 2500ms | 4293.24ms |
| `/policies/return-refund-policy` | 2500ms | 4366.73ms |
| `/packing` | 2500ms | 4062.63ms |

## Server Cleanup

The controlled verification server started for this sprint was stopped after checks.
