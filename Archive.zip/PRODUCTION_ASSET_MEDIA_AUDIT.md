# Production Asset Media Audit

Date: 2026-07-01
Result: NO-GO until media risk is approved or remediated

## Large Asset Inventory

Files above 1 MB include:

- `public/Welcoming.mp4` around 13 MB
- `public/hero/banner.png` around 11 MB
- `public/hero/timeless.JPG` around 7.5 MB
- `public/welcome.webp` around 6.8 MB
- `public/hero/banner1.png` around 5.8 MB
- `public/packaging/normalpkg-2.png` around 5.1 MB
- `public/Ftt_logo_navbar.svg` around 4.9 MB
- `public/packaging/normalpkg-1.png` around 4.8 MB
- `public/banner/collection_banner.png` around 4.1 MB
- `public/banner/collection-banner2.png` around 3.8 MB
- `public/Welcoming.webm` around 3.0 MB
- `public/media/home-cover.png` around 2.9 MB

Additional hero, founder, packaging, category, and banner assets are also above 1 MB.

## Candidate Optimized Assets

The worktree contains `public/seo-candidates/` with smaller AVIF/WebP/video candidates. These were not applied in this audit.

## Deleted Assets in Dirty Tree

Tracked assets currently deleted:

- `public/banner/banner1.png`
- `public/banner/banner2.gif`
- `public/banner/banner3.png`
- `public/banner/banner4.png`

These deletions are approval-required before production.

## Restrictions Honored

This audit did not:

- delete assets
- replace live media
- change product crops
- change colors
- modify media references
- alter visible content

## Decision

NO-GO until:

- large media LCP impact is resolved or accepted,
- deleted tracked media files are owner-approved,
- any optimized replacements are visually approved against brand guidelines.
