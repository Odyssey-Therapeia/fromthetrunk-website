# Production Toolchain Audit

Date: 2026-07-01
Result: NO-GO due lockfile/audit and local Node mismatch

## Package Manager

`package.json` declares:

```json
"packageManager": "pnpm@10.28.0"
```

The requested wrapper confirmed:

```text
pnpm --version -> 10.28.0
```

## Node Version

`package.json` declares:

```json
"node": ">=20.9 <25"
```

Local default shell Node:

```text
v25.4.0
```

Requested command wrapper Node:

```text
v22.23.1
```

Assessment:

- Local default Node is outside the package engine range.
- The audit commands were run through the requested Node 22 wrapper to avoid false failures.
- Developers should use Node 22 or another `<25` supported runtime before production push.

## Required Command Results

Passed:

- `git diff --check`
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm --version`
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run lint`
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsc --noEmit --pretty false`
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run build`
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run test`

Failed:

- `npx -y -p node@22 -p pnpm@10.28.0 pnpm audit`
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run verify:ux`
- `npx -y -p node@22 -p pnpm@10.28.0 pnpm run agent:check`

Blocked/failed readiness command:

- `pnpm exec node --env-file=.env.local --import tsx scripts/demo-readiness.ts` failed because the repo scripts reference `tsx`, but `tsx` is not installed in project dependencies.
- Running the same readiness script through a temporary `npx tsx` CLI succeeded technically but returned FAIL due missing readiness checks.

## Build Notes

`pnpm run build` passed with Next.js 16.2.9 and Turbopack.

Build warning observed:

```text
[seo] Invalid production canonical origin "http://localhost:3000"; using https://www.fromthetrunk.shop.
```

This is an environment warning and must be cleared for production by setting canonical production URL envs.

## Optional Script Inventory

Available scripts include:

- `verify`
- `verify:ux`
- `agent:check`
- `lhci:*`
- `demo:check`
- `db:*`

No `test:e2e`, `test:unit`, `test:integration`, `format:check`, or `analyze` script exists in `package.json`.

## Decision

NO-GO until:

- Lockfile is restored.
- `pnpm audit` can run.
- Node runtime is pinned to the package engine range for all production verification.
- `tsx` script dependency policy is resolved, or scripts stop depending on undeclared loaders.
