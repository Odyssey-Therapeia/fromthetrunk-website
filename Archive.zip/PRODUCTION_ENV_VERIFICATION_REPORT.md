# FTT Production Env Verification Report

Date: 2026-07-01

## Scope

No secrets were printed or written. This report verifies env requirements by key name only.

## Required Keys From `scripts/demo-readiness.ts`

| Key | Local `.env.local` key inventory | Production status | Notes |
| --- | --- | --- | --- |
| `DATABASE_URL` | Present | Not verified | Required for DB-backed runtime |
| `NEXTAUTH_SECRET` | Present | Not verified | Auth secret |
| `NEXTAUTH_URL` | Present | Not verified | Auth canonical URL |
| `NEXT_PUBLIC_SERVER_URL` | Present | Not verified | Public site origin |
| `RAZORPAY_KEY_ID` | Present | Not verified | Payment secret path |
| `RAZORPAY_KEY_SECRET` | Present | Not verified | Payment secret path |
| `RAZORPAY_WEBHOOK_SECRET` | Present | Not verified | Webhook verification |
| `NEXT_PUBLIC_RAZORPAY_KEY_ID` | Present | Not verified | Public payment key |
| `RESEND_API_KEY` | Present | Not verified | Email sending |
| `RESEND_FROM_EMAIL` | Present | Not verified | Email sender |
| `CRON_SECRET` | Missing from local key inventory | Not verified | Required by demo readiness |
| `ADMIN_API_SECRET` | Missing from local key inventory | Not verified | Required by demo readiness |
| OAuth provider pair | No complete pair observed in local key inventory | Not verified | Demo readiness requires at least one configured OAuth pair |

## Command Result

`npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsx scripts/demo-readiness.ts`

Result: failed because the command was run without loading `.env.local`; it reported missing required vars plus missing OAuth pair and DB check failure from absent `DATABASE_URL`.

## Production Blocker Status

Production secrets cannot be confirmed from the local working tree. Before production push, verify the required keys exist in Vercel production and preview environments. Locally, `CRON_SECRET`, `ADMIN_API_SECRET`, and an OAuth provider pair were not present in the key inventory checked.
