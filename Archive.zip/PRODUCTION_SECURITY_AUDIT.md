# Production Security Audit

Date: 2026-07-01
Result: NO-GO because dependency audit is blocked

## Headers

Sampled local responses include:

- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `X-DNS-Prefetch-Control: on`
- `Permissions-Policy: camera=(), microphone=(), geolocation=(), interest-cohort=()`
- `Strict-Transport-Security: max-age=31536000; includeSubDomains`
- `Content-Security-Policy-Report-Only`

`/checkout` has a dedicated `X-Frame-Options: SAMEORIGIN` override for Razorpay modal compatibility.

## CSP

CSP is report-only, not enforced.

Allowed external surfaces include:

- Razorpay
- Google Analytics / Tag Manager
- Vercel Blob public storage
- Unsplash
- Behold / Instagram CDN
- OpenStreetMap tile endpoints

Risk:

- Report-only CSP is useful for monitoring, but it does not block violations.
- Enforcement should be a separate approval-backed rollout.

## API and Mutation Guards

Observed code:

- Hono same-origin CORS and mutation guard.
- NextAuth token based auth middleware.
- Admin fallback via `ADMIN_API_SECRET`.
- Razorpay webhook signature verification with timing-safe comparison.
- Payment signatures verified with HMAC/timing-safe compare.
- Managed redirects block dangerous admin-created redirect patterns in route code.
- Money paths are excluded from proxy-managed redirect consultation.

## Dependency Audit

`pnpm audit` failed because `pnpm-lock.yaml` is missing:

```text
ERR_PNPM_AUDIT_NO_LOCKFILE No pnpm-lock.yaml found: Cannot audit a project without a lockfile
```

This is a production blocker.

## Local Exposure Findings

Local `/api/v2/docs` and `/api/v2/openapi.json` returned 200.

Code policy:

```text
NODE_ENV !== "production" || FTT_ENABLE_API_DOCS === "true"
```

Production must verify `FTT_ENABLE_API_DOCS` is not enabled unless explicitly approved.

## Secret/Env Findings

Local readiness check reported:

- `CRON_SECRET` missing
- `ADMIN_API_SECRET` missing
- OAuth provider pair missing

## Decision

NO-GO until:

- lockfile is restored,
- `pnpm audit` passes or accepted findings are documented,
- production secret/env state is verified,
- API docs exposure is confirmed off or approved.
