# FTT Production SEO Search Console Recheck

Date: 2026-07-01

## Local Production-Mode Checks

Checked against a controlled production-mode local server:

- `/robots.txt`: emits canonical sitemap URL `https://www.fromthetrunk.shop/sitemap.xml` and disallows private/system API routes.
- `/sitemap.xml`: emits canonical `https://www.fromthetrunk.shop/...` URLs.
- `/llms.txt`: emits canonical `https://www.fromthetrunk.shop/...` links.

## What Was Not Done

- No Google Search Console sitemap submission.
- No URL inspection or indexing request.
- No backlink work.
- No live production crawl.
- No public content rewrite.

## Notes

Local build emits warnings when `.env.local` provides `http://localhost:3000` as the origin, but the SEO helper falls back to `https://www.fromthetrunk.shop` for production canonical output.

## Production Status

Local generated SEO outputs look canonical, but Search Console status remains an external manual check.
