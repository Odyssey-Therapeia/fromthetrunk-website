# Production Database Migration Audit

Date: 2026-07-01
Result: NO-GO

## Drizzle Configuration

`drizzle.config.ts`:

- loads `.env.local`
- requires `DATABASE_URL`
- uses schema `./db/schema.ts`
- outputs to `./drizzle`
- dialect: PostgreSQL
- strict: true
- verbose: true

## Migration Files

Migration directory includes:

- `0000` through `0023`
- untracked `0024_order_item_selected_options.sql`
- untracked `0025_payment_hardening.sql`

Git status shows:

- modified `db/schema.ts`
- modified `db/queries/events.ts`
- modified `db/queries/orders.ts`
- modified `db/queries/products.ts`
- untracked migration files `0024` and `0025`

## Read-Only DB Evidence

The readiness script queried the configured database and found:

```text
57 published products found
```

No migrations were run by this audit.

## Risks

- Untracked migration files are not production-safe until reviewed and committed or explicitly excluded.
- Modified schema/query files affect commerce, orders, product stock, payment hardening, and selected options.
- There is no production migration rehearsal evidence in this audit.
- There are no rowcount before/after checks for new migrations.
- The audit did not verify live Neon branch state.

## Decision

NO-GO until:

- migration ownership is approved,
- migrations are reviewed,
- production/staging migration rehearsal is performed,
- rowcount and rollback/restore plan are documented,
- dirty DB/query changes are explicitly signed off.
