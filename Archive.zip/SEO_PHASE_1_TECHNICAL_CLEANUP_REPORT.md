# FTT SEO Phase 1 Technical Cleanup Report

Date: 2026-06-30
Scope: technical SEO cleanup and indexing readiness. No visible copy, guide content, backlink work, fake schema, auth, OTP, checkout, payment/Razorpay, cart reservation, shipping/payment math, order ownership, wishlist ownership, stock, pricing, database schema, or migrations were changed.

## Files Changed

Phase 1 technical SEO changes:

- `.env.production.example`
- `app/(admin)/layout.tsx`
- `app/(site)/account/layout.tsx`
- `app/(site)/cart/page.tsx`
- `app/(site)/checkout/page.tsx`
- `app/(site)/checkout/confirmation/page.tsx`
- `app/(site)/packing/page.tsx`
- `app/(site)/search/page.tsx`
- `app/(site)/why/page.tsx`
- `app/llms.txt/route.ts`
- `app/sitemap.ts`
- `lib/content/nav-menu.ts`
- `lib/content/reserved-slugs.ts`
- `lib/seo/route-metadata.ts`
- `next.config.ts`
- `tests/unit/seo-phase-1-technical-cleanup.test.ts`
- `tests/unit/site-origin.test.ts`

Existing image SEO files from the prior image phase remain in the working tree:

- `app/(site)/collection/[slug]/page.tsx`
- `lib/seo/image-urls.ts`
- `lib/seo/json-ld.ts`
- `tests/unit/seo-image-optimization.test.ts`
- `tests/unit/seo-production-hardening.test.ts`

Pre-existing unrelated dirty file:

- `components/layout/site-header-nav.tsx`
  - Already dirty before this Phase 1 pass.
  - Current diff removes three Shop By filter items.
  - Not modified in this Phase 1 work.

Unrelated dirty file observed after implementation:

- `app/(site)/how-it-works/page.tsx`
  - Contains visible copy and component changes outside this SEO Phase 1 scope.
  - Not modified in this Phase 1 work.
- `app/(site)/how-it-works/how-it-works-experience.tsx`
  - Untracked component file paired with the unrelated How It Works page change.
  - Not created or modified in this Phase 1 work.

## Baseline And Safety

`.env.production.example` now uses the real canonical production origin:

- `SITE_URL=https://www.fromthetrunk.shop`
- `NEXT_PUBLIC_SERVER_URL=https://www.fromthetrunk.shop`
- `NEXTAUTH_URL=https://www.fromthetrunk.shop`

Current `.env.local` is not production-aligned:

- `NEXT_PUBLIC_SERVER_URL=http://localhost:3000`
- `NEXTAUTH_URL=https://fromthetrunk.com`

That local state is why build logs still show the canonical-origin fallback warning. The production guard falls back to `https://www.fromthetrunk.shop`.

The existing block/homepage test failures were treated as unrelated baseline failures for this SEO phase. They were not fixed here.

## Policy Canonical Decision

Decision: `/policies/[slug]` is the canonical policy family.

Permanent redirects added:

- `/privacy-policy` -> `/policies/privacy-policy`
- `/terms-of-service` -> `/policies/terms-of-service`
- `/shipping-policy` -> `/policies/shipping-delivery-policy`
- `/return-policy` -> `/policies/return-refund-policy`

Sitemap and `llms.txt` now use the canonical `/policies/*` URLs. Fallback footer/nav data and packing support links now point to canonical policy URLs without changing link labels.

## `/founders` Decision

Decision: `/our-team` is the final public route.

Change:

- `/founders` -> `/our-team` is now a permanent redirect.

## `/why` Decision

Decision: Option A, keep `/why` as an indexable public route.

Reason:

- `/why` is an existing brand/story route.
- It can be made indexable with metadata and sitemap/llms inclusion without changing visible copy.

Changes:

- Added full canonical metadata via `WHY_PAGE_METADATA`.
- Added `/why` to sitemap.
- Added `/why` to `llms.txt`.

## Sitemap Changes

Sitemap now excludes duplicate legacy top-level policy URLs and includes:

- `/policies`
- `/policies/[slug]`
- `/why`
- existing canonical public pages
- approved keyword pages
- public non-sold product pages

Sitemap still excludes:

- cart
- checkout
- account
- wishlist
- admin
- API
- search
- query URLs
- sold products
- draft/private products
- duplicate policy URLs
- `/founders`

## Robots And Noindex Changes

Robots already disallowed private/system routes and still points to:

- `https://www.fromthetrunk.shop/sitemap.xml`

Added/shared route metadata helpers:

- `PRIVATE_NOINDEX_ROBOTS`
- `ADMIN_METADATA`
- `WHY_PAGE_METADATA`

Noindex is now centralized for:

- admin layout
- account layout
- cart
- checkout
- checkout confirmation
- search

This did not change auth behavior or admin business logic.

## `llms.txt` Changes

`llms.txt` now aligns with canonical public route decisions:

- includes `/why`
- includes `/sell-your-saree`
- includes existing approved guide routes
- includes `/policies` and canonical `/policies/*` policy routes
- excludes duplicate top-level policy URLs
- excludes sold products from product links
- continues to exclude private/transactional/admin/API routes

## Tests Added Or Updated

Added:

- `tests/unit/seo-phase-1-technical-cleanup.test.ts`

Updated:

- `tests/unit/site-origin.test.ts`

SEO-focused test coverage now checks:

- production canonical origin
- Vercel preview origin rejection
- no localhost/preview URLs in SEO outputs
- sitemap inclusion/exclusion
- one canonical policy family
- `/founders` permanent redirect
- `/why` indexing decision
- admin/private noindex constants
- robots private/system disallows
- `llms.txt` canonical route alignment
- product JSON-LD remains truthful
- no fake review/rating schema
- production env example canonical values

Focused SEO test run:

- Command: `pnpm exec vitest run tests/unit/seo-phase-1-technical-cleanup.test.ts tests/unit/seo-production-hardening.test.ts tests/unit/site-origin.test.ts tests/unit/seo-image-optimization.test.ts tests/unit/aeo-schema-completeness.test.ts tests/unit/json-ld-render.test.ts`
- Result: pass, 6 files, 71 tests.

## Command Results

| Command | Result | Notes |
| --- | --- | --- |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run lint` | Pass | ESLint completed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm exec tsc --noEmit --pretty false` | Pass | TypeScript completed. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run build` | Pass | Next build completed. Local env still triggers canonical fallback warning. |
| `npx -y -p node@22 -p pnpm@10.28.0 pnpm run test` | Fail | Existing unrelated block/homepage baseline failures remain. |

Full test failure summary:

- 4 failed files, 125 passed.
- 25 failed tests, 1623 passed.
- Failing files:
  - `tests/unit/block-hero.test.ts`
  - `tests/unit/block-p308-new-blocks.test.ts`
  - `tests/unit/blocks-trust-signals.test.ts`
  - `tests/unit/homepage-blocks.test.ts`

## Remaining Blockers

- Full test suite is not green because existing block/homepage tests still fail.
- Mobile/performance validation is still a blocker from the prior image phase.
- `.env.local` is intentionally local and not production-aligned; production deployment envs must use the production canonical origin values.
- Legacy top-level policy route files still exist, but redirects consolidate them before indexing.
- Search Console sitemap submission and production URL inspection are still required before production indexing expansion.

## GO / NO-GO

- Phase 1 technical SEO cleanup: GO.
- One canonical policy family: GO.
- Permanent redirect for final `/founders` route: GO.
- `/why` route decision: GO, indexable.
- Sitemap canonical alignment: GO.
- Private/system route noindex and robots alignment: GO.
- `llms.txt` canonical alignment: GO.
- Broad production indexing readiness: NO-GO until the full test baseline is green or explicitly accepted, mobile/performance blockers are resolved, and production Search Console validation is complete.
