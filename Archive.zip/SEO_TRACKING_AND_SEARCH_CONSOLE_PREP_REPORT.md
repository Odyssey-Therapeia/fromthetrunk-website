# Tracking And Search Console Prep Report

Date: 2026-07-01

## Existing Tracking Surfaces

- Vercel Analytics in `app/(site)/layout.tsx`.
- Vercel Speed Insights in `app/(site)/layout.tsx`.
- GTM gate/script wiring in `app/(site)/layout.tsx`.
- Internal analytics/event code exists in app/lib areas.
- No new tracker was installed.

## Search Console Prep

- Preferred property: `https://www.fromthetrunk.shop`.
- Sitemap URL: `https://www.fromthetrunk.shop/sitemap.xml`.
- Do not submit sitemap until production is deployed, live endpoints return 200, and user explicitly approves.

Priority URL inspection list after deploy:

- `/`
- `/collection`
- one live PDP
- `/sell-your-saree`
- `/faqs`
- `/why`
- `/policies/privacy-policy`
- `/policies/shipping-delivery-policy`
- `/guides/what-is-a-pre-loved-saree`
- `/guides/pre-loved-vs-second-hand-saree`

## Tool Checklist

| Tool | Timing | Use | Requirement | Risk |
| --- | --- | --- | --- | --- |
| Google Search Console | launch | indexing, sitemap, URL inspection | property verification | low |
| GA4 | before/launch | acquisition and conversion analytics | approved measurement ID/GTM | privacy/cookie disclosure |
| Microsoft Clarity | later | UX recordings/heatmaps | approval and privacy review | medium |
| Screaming Frog | launch/post | crawl QA | local desktop tool | low |
| Ahrefs/Semrush/free backlink checker | post-launch | backlink monitoring | account/API if paid | low |
| DataForSEO | later | SERP/backlink API | paid API key | medium |
| Peec AI | later | AEO/AI visibility tracking | account/API | medium |
| Trustindex | later | real reviews only | real visible reviews | high if fake/misaligned |

## Status

Search Console verification prep: `GO`.

Sitemap submission: `NO-GO until production deploy, live verification, and explicit approval`.

