# Large Asset Action Plan

Date: 2026-07-01

## Inventory

| Asset | Size | Active Reference | Route/Use | LCP Risk | Recommended Action | Approval |
| --- | ---: | --- | --- | --- | --- | --- |
| `public/Welcoming.webm` | 3,171,178 B | `home-intro-gate.tsx` | Homepage intro | Medium | Keep for now; consider 1080p muted candidate after visual approval | Required |
| `public/Welcoming.mp4` | 13,616,217 B | `home-intro-gate.tsx` fallback | Homepage intro | High fallback risk | Replace fallback with optimized MP4 candidate after visual approval | Required |
| `public/welcome-poster.avif` | 23,502 B | `home-intro-gate.tsx` | Homepage intro poster | Low | Keep | No |
| `public/hero/banner.png` | 11,229,121 B | Homepage/landing sources | Above-fold/editorial | High | Switch to approved WebP/AVIF derivative only after visual QA | Required |
| `public/hero/timeless.JPG` | 7,827,034 B | Homepage/landing sources | Editorial | High | Switch to approved WebP/AVIF derivative only after visual QA | Required |
| `public/hero/banner1.png` | 6,106,267 B | Homepage/landing sources | Editorial | High | Switch to approved WebP/AVIF derivative only after visual QA | Required |
| `public/Ftt_logo_navbar.svg` | 5,119,297 B | Logo asset | Header/logo | Medium | Replace embedded-raster SVG with proper small vector/raster logo after brand approval | Required |
| `public/banner/collection_banner.png` | 4,254,829 B | Metadata/collection banner | OG/collection | Medium | Switch to approved compressed social/hero derivative | Required |
| `public/media/home-cover.png` | 3,020,948 B | Homepage/landing media | Editorial | Medium | Switch to approved compressed derivative | Required |
| `public/packaging/normalpkg-1.png` | 5,018,169 B | Checkout packaging | Checkout | Out of SEO scope | Leave untouched | Required for any change |
| `public/packaging/normalpkg-2.png` | 5,306,655 B | Checkout packaging | Checkout | Out of SEO scope | Leave untouched | Required for any change |
| `public/banner/banner1.png` | Missing | Old banner | Unknown | Unknown | Do not restore/delete without owner decision | Required |
| `public/banner/banner2.gif` | Missing | Old banner | Unknown | Unknown | Avoid GIF if reintroduced; use WebP/video candidate | Required |
| `public/banner/banner3.png` | Missing | Old banner | Unknown | Unknown | Do not restore/delete without owner decision | Required |
| `public/banner/banner4.png` | Missing | Old banner | Unknown | Unknown | Do not restore/delete without owner decision | Required |

## Welcoming Media Details

- `public/Welcoming.webm`: VP9 video, 3840x2160, Opus audio.
- `public/Welcoming.mp4`: H.264 video, 3840x2160, AAC audio, about 6.96 seconds.
- Source order is WebM first, MP4 second.
- Poster exists.
- Preload is `metadata`.

## Candidate Policy

Only candidates were generated. No live references were switched in this phase because hero/editorial/video assets require visual approval.

