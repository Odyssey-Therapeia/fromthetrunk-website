# Internal Linking Final Recheck

Date: 2026-07-01

## Checks

- Important public pages have crawlable `<Link>` or `<a href>` links.
- No JS-only SEO-critical navigation was found on `/why` after aligning the stale test with current UI.
- Policy detail pages link to `/faqs` and related canonical policy pages.
- PDP pages link back to collection and trust/support guide/policy surfaces.
- Keyword content pages link to home/collection and configured internal destinations.
- Robots/noindex routes are not used as SEO targets.
- Legacy policy routes are not sitemap targets.

## Current Link Coverage

| Page | Inbound/Global Coverage | Outbound Coverage | Notes |
| --- | --- | --- | --- |
| Homepage | high | collection, story, product areas | dirty/user-owned |
| Collection | high | PDPs, filters, products | query filter links exist for UX but sitemap excludes queries |
| PDP | high from collection | collection, guide/policy/trust links | product image/schema OK |
| Policies | footer/header/content | canonical policies, FAQ | good |
| FAQs | footer/content | policies | good |
| Why | header/more/footer/llms/sitemap | collection | adding more visible links requires approval |
| Sell Your Saree | footer/keyword/sitemap/llms | internal links from template | content approval required for any visible anchor changes |
| Our Story | header/footer/home | collection | good |
| Our Team | header/llms/sitemap | collection/story areas | good |
| How It Works | header/footer/sitemap/llms | collection | user-owned dirty |
| Packing | sitemap/content support links | shipping/returns | good |
| Guides | footer/PDP/keyword configs | collection and related pages | good |

## Approval-Required Improvements

- Any new visible anchor text or section-level links on `/why`, `/sell-your-saree`, homepage, or footer.
- Any change to header navigation labels or query-link behavior.

