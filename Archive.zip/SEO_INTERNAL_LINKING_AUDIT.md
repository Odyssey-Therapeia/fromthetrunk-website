# SEO Internal Linking Audit

Date: June 30, 2026

This is an audit only. No visible link text or page copy was changed for internal linking.

## Current Public Linking Surface

| Surface | Finding | Status |
|---|---|---|
| Header navigation | Links to `/collection`, `/our-team`, `/faqs`; shop-by entries include query URLs such as `/collection?tags=top-pick` and `/collection?type=blouse`. | Query URLs are useful UX links but should not be treated as sitemap/index targets. |
| Footer | Links to `/collection`, `/our-story`, `/how-it-works`, `/sell-your-saree`, guide routes, canonical policy routes, and canonical fabric/occasion landing pages. | Good canonical base. |
| Homepage | Links to `/collection` and `/our-story`; product cards link to PDPs. | Missing direct visible links to `/faqs`, `/why`, and `/sell-your-saree` from the homepage body. Footer covers some. |
| Collection | Links to products, collection filters, canonical fabric/occasion pages, and collection anchors. | Query filter URLs are UI links; not index targets. |
| PDP | Breadcrumb links to `/` and `/collection`; fabric guide link when mapped; guide link to `/guides/what-is-a-pre-loved-saree`. | Could add support links later to how-it-works, packing, shipping, and returns. |
| FAQ | Links to every canonical `/policies/[slug]` page and `/policies`. | Good canonical policy linking. |
| Policies | Hub links to every canonical policy detail; detail pages link back to `/policies`. | Good hub/detail structure. Cross-policy and FAQ links can be improved later. |
| `/why` | Links to `/collection` and `/our-team`. | Needs more inbound internal links; currently present in nav data and llms.txt but not broadly linked in visible page body. |
| `/our-team` | Links to `/collection`. | Footer/header provide inbound links. |
| `/sell-your-saree` | Footer and SEO keyword pages link here. | Needs more visible inbound links before broader indexing. |
| Guides | Keyword landing pages link to collection and sell-your-saree. | Good, but do not create new guide pages yet. |

## SEO Target Safety Checks

| Check | Result |
|---|---|
| Real `href` / Next `Link` href used for important links | Passed for audited public links. |
| JS-only SEO-critical links | No critical JS-only public SEO route found. |
| Localhost links | No public SEO target links to localhost found. Localhost checks exist only in config/safety code. |
| Vercel preview links | No public SEO target links to `vercel.app` found. |
| Private/noindex targets used as SEO targets | Cart/checkout/account links exist for commerce UX only, not sitemap/SEO targets. |
| Legacy top-level policy links | Footer/nav/support/llms use canonical `/policies/[slug]`. Legacy route files still exist for redirects/backward compatibility. |
| Arbitrary query-filter URLs | Header and category/fabric UX use query URLs. These are noindex by collection metadata when filters are active and should not enter sitemap. |

## Items To Keep As Audit Notes

- `components/widgets/floating-whatsapp.tsx` still checks old paths like `/terms-of-service` for visibility logic; this is not an SEO link target.
- `components/layout/site-header-nav.tsx` contains pre-existing unrelated dirty changes and should not be edited without ownership confirmation.
- `app/(site)/how-it-works/how-it-works-experience.tsx` contains a visible CTA to `/sell`; this file is user-owned dirty work and was not changed. Confirm whether `/sell` should become `/sell-your-saree` before SEO rollout.
