# Outreach Templates

Date: 2026-07-01

Do not send without approval.

## Founder Story Pitch

Subject: Story idea: circular luxury sarees and the wardrobes they come from

Hi [Name],

I am reaching out from From the Trunk, a Bengaluru-rooted platform for authenticated pre-loved luxury sarees. We are preparing a story around textile memory, restoration, and circular fashion in Indian wardrobes.

Would this be a fit for your fashion/sustainability coverage?

Best,
[Sender]

## Resource Pitch

Subject: Resource for your saree care readers

Hi [Name],

Your article on [topic] may be a useful fit for our upcoming saree care resource. It focuses on practical storage, gentle care, and preserving heirloom textiles.

If useful, I can share the final guide after publication.

Best,
[Sender]

## Unlinked Mention

Subject: Quick note on your From the Trunk mention

Hi [Name],

Thank you for mentioning From the Trunk in [article/page]. If helpful for readers, the canonical page is [URL].

Best,
[Sender]

