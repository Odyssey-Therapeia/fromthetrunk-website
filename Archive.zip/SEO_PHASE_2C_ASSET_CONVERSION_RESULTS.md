# SEO Phase 2C Asset Conversion Results

Date: June 30, 2026

Decision: no source asset was replaced and no code reference was changed. The user has not approved visual media replacement, and Phase 2C is a prep phase. The table below records source sizes and route usage so optimized WebP/AVIF/MP4/WebM candidates can be generated and compared after approval.

| Original file | Source size | Route usage found | New candidate | Size reduction | Visual diff / screenshot notes | Code reference changed |
|---|---:|---|---|---:|---|---|
| `public/Welcoming.mp4` | 13.0 MB | `components/sections/home-intro-gate.tsx` intro video. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/hero/banner.png` | 10.7 MB | Fallback/product/story/category imagery in `landing-sections`, `social-section`, `fabric-category-section`. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/banner/banner2.gif` | 10.2 MB | No active source reference found in `app`, `components`, `lib`, or `tests`. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/hero/timeless.JPG` | 7.5 MB | Fallback/product/story/category imagery in `landing-sections`, `social-section`, `fabric-category-section`. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/banner/banner3.png` | 6.4 MB | No active source reference found; active campaign uses `newbanner3.png`. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/banner/banner4.png` | 6.1 MB | No active source reference found. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/hero/banner1.png` | 5.8 MB | Fallback/product/story/category imagery in `landing-sections`, `social-section`, `fabric-category-section`. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/banner/banner1.png` | 5.4 MB | No active source reference found. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/Ftt_logo_navbar.svg` | 4.9 MB | No active source reference found after navbar uses `Ftt_logo_navbar.png`. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/packaging/normalpkg-1.png` | 4.8 MB | `components/checkout/packaging-step.tsx`; checkout is out of scope. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/packaging/normalpkg-2.png` | 5.1 MB | `components/checkout/packaging-step.tsx`; checkout is out of scope. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/banner/collection_banner.png` | 4.1 MB | Default OG image, keyword OG image, and current PDP/product fallback data. | Not generated; approval required. | N/A | Not reviewed. | No |
| `public/media/home-cover.png` | 2.9 MB | Homepage cover, story/social/category fallback, and `/why` fallback image pool. | Not generated; approval required. | N/A | Not reviewed. | No |

## Approval Checklist

- Approve which assets may receive generated variants.
- Approve acceptable output formats per route: WebP/AVIF for images, MP4/WebM for video.
- Review desktop and mobile screenshots before changing code references.
- Do not alter product image crop, color, or representation without explicit product/media approval.
- Keep checkout packaging assets out of SEO optimization changes unless checkout ownership is separately approved.
