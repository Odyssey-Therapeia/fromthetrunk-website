# Linkable Asset Plan

Date: 2026-07-01

## Priority Assets

| Asset | Target Page | Value | Status |
| --- | --- | --- | --- |
| Founder/circular fashion story | `/our-story`, `/our-team`, `/why` | PR/editorial | existing pages, no outreach yet |
| Sell/consign saree guide | `/sell-your-saree` | seller acquisition | existing page |
| Saree care guide | future `/guides/saree-care-guide` | resource links | proposal only |
| Saree fabric guide | future `/guides/saree-fabric-guide` | resource links/internal collection links | proposal only |
| Sustainable sarees guide | future `/guides/sustainable-sarees` | sustainability publications | proposal only |
| Press/media kit | future `/press` | journalist support | proposal only |

## Brand Requirements

Assets must feel like FTT editorial pages, not generic SEO blogs.

