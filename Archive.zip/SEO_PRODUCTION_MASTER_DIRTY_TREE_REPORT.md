# FTT SEO Production Master Dirty Tree Report

Date: 2026-07-01

## Scope Boundary

This phase was run against an already dirty worktree. I treated the existing dirty tree as user-owned unless the file was created or changed during this pass.

No existing written storefront content, route, checkout, cart, payment, auth, stock, pricing, schema migration, or live media reference was changed for this SEO pass.

## Commands Used

- `git status --short`
- `find .lighthouseci -maxdepth 1 -type f -name 'lhr-*.json' -print`
- `git diff --check` passed after reports were added.

## High-Risk Dirty Areas To Protect

- `components/layout/site-header-nav.tsx`: dirty before this pass; do not overwrite.
- `app/(site)/how-it-works/page.tsx`: dirty before this pass; do not edit animation/page behavior without approval.
- `app/(site)/how-it-works/how-it-works-experience.tsx`: untracked user-owned route implementation.
- `app/(site)/page.tsx`: dirty before this pass; homepage/landing content protected.
- `components/sections/landing-sections.tsx`: dirty before this pass; homepage/landing content protected.
- `components/sections/home-intro-gate.tsx`: dirty before this pass; Welcoming media behavior protected.
- `public/our-story/`: untracked story media; do not delete or replace without approval.
- `pnpm-lock.yaml`: deleted before/at current workspace state. This blocks `pnpm audit` and production reproducibility until resolved or explicitly accepted.
- `public/banner/banner1.png`, `public/banner/banner2.gif`, `public/banner/banner3.png`, `public/banner/banner4.png`: deleted in current workspace state. Do not restore/delete without owner decision.

## Broad Dirty Tree Summary

The dirty tree includes modified API routes, admin and storefront pages, cart/checkout/account code, product/card/gallery components, SEO utilities, analytics/security tests, database query files, schema files, checkout/payment/order code, and several new untracked route/support files. Those areas are treated as user-owned unless explicitly changed in this pass.

Notable dirty groups:

- API/Hono and route migration files under `api/hono/**` and `app/api/**`.
- Admin, account, cart, checkout, collection, policy, search, homepage, why, packing, and how-it-works pages under `app/(site)/**`.
- Layout/header/footer/menu components under `components/layout/**`.
- Product, catalog, checkout, cart, and section components.
- Order/payment/checkout/schema/query code under `lib/**` and `db/**`.
- SEO utilities under `lib/seo/**`, some of which appear to come from earlier SEO phases.
- Tests under `tests/unit/**` and `tests/e2e/**`.
- Untracked media under `public/footer/`, `public/our-story/`, `public/Welcoming.webm`, `public/welcome-poster.avif`, and AVIF banner files.

## Files Changed By This Pass

- `tests/unit/seo-phase-2b-2c.test.ts`: one stale internal-link test was updated to match the current visible `/why` page without adding visible links or changing copy.
- `public/seo-candidates/**`: generated optimized candidate media only; no live code references changed.
- `SEO_*.md` and `SEO_DIGITAL_PR_OUTREACH_LIST.csv`: documentation/report artifacts.

## Files Safe To Change In This Pass

- SEO report files.
- Non-live optimized asset candidate files under `public/seo-candidates/`.
- Narrow SEO test assertions that align with the current approved visible UI.

## Files Not Touched For Safety

- Header nav and active user navigation changes.
- Homepage/landing UI and copy.
- How-it-works route and animation.
- Checkout/cart/payment/Razorpay/order/account/auth logic.
- Product pricing, stock, reservation, and database migrations.
- Existing legal, FAQ, story, why, sell-your-saree, product, and homepage written copy.
- Live media references for hero/editorial/product/story assets.

## Welcoming Media Current State

- Active references: `components/sections/home-intro-gate.tsx`.
- Source order: `/Welcoming.webm` first, `/Welcoming.mp4` fallback second.
- Poster: `/welcome-poster.avif`.
- Preload mode: `metadata`.
- Behavior: muted, autoplay, playsInline, desktop intro gated by session/reduced-motion logic.
- Risk: `public/Welcoming.mp4` remains a 13.6 MB fallback and both sources remain declared in the video element. Candidate replacements were generated but not wired.

## Production Safety Result

Production readiness is `NO-GO` until the lockfile state is resolved or explicitly accepted, `verify:ux` is green or accepted with documented exceptions, and final owner review approves any live media swaps.
