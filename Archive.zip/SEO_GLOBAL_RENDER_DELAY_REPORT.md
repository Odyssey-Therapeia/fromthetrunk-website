# Global Render Delay Report

Date: 2026-07-01

## Inspected Surfaces

- `app/(site)/layout.tsx`
- `components/widgets/site-widgets.tsx`
- `components/sections/home-intro-gate.tsx`
- `app/globals.css`
- Header/footer layout files
- Route-specific policy/FAQ/why/sell pages

## Findings

- Static text-heavy routes still show mobile LCP around 4 seconds in LHCI, so the issue is not limited to product imagery.
- Global layout includes Vercel Analytics, Speed Insights, GTM afterInteractive, shared header/footer, and delayed site widgets.
- `components/widgets/site-widgets.tsx` already defers widget mounting by 6500 ms.
- Fonts are loaded through `next/font` with display swap.
- Home intro video is client-gated and uses WebM first, MP4 fallback, poster, and `preload="metadata"`.
- No safe non-visual global code change was obvious without risking visible behavior or user-owned route changes.

## Local Console Noise

Local built-server Playwright runs report Vercel script MIME errors for:

- `/_vercel/insights/script.js`
- `/_vercel/speed-insights/script.js`

These are local-only production smoke-test artifacts and not page render blockers.

## Recommendations

- Run a clean LHCI trace after resolving the deleted lockfile and the flaky `/policies/terms-of-service` LHCI 500.
- Use the optimized asset candidates for visual review and then replace approved live media.
- Confirm whether global analytics should be disabled in local LHCI or mocked to reduce console noise.
- Investigate header/footer bundle contribution only after user-owned nav/footer changes settle.

