# Backlink Policy

Date: 2026-07-01

## Approved

- Founder story outreach.
- Circular fashion features.
- Sustainable fashion features.
- Saree care/fabric guide resource pitching after approved pages exist.
- Unlinked mention reclamation.
- Editorial interviews.
- Local/Bengaluru business stories.
- Wedding/lifestyle styling features.
- High-quality relevant directories only after review.

## Forbidden

- Paid dofollow links.
- PBNs.
- Link farms.
- Fake guest posts.
- Fake awards.
- Fake reviews.
- AI spam outreach.
- Comment spam.
- Irrelevant directories.
- Mass directory submissions.
- Link exchanges solely for SEO.
- Guaranteed ranking/indexing vendors.

## Execution Gate

Backlink outreach requires explicit owner approval.

