# Production Post Launch SEO Readiness

Date: 2026-07-01
Status: not ready for post-launch SEO actions

## Current Status

Do not submit sitemap or request indexing yet.

Reasons:

- lockfile missing
- mobile LCP gate failing
- production env not verified
- dirty tree ownership unresolved
- production deployment not performed in this audit

## Ready Criteria

Post-launch SEO begins only after:

- production deploy is approved and complete
- `https://www.fromthetrunk.shop/sitemap.xml` returns production URLs
- `https://www.fromthetrunk.shop/robots.txt` points to production sitemap
- page canonicals use production URLs
- no checkout/cart/account pages are indexable
- representative PDP JSON-LD validates
- mobile CWV risk is fixed or explicitly accepted

## First Search Console Actions

After ready criteria are met:

1. Submit sitemap.
2. Inspect home URL.
3. Inspect `/collection`.
4. Inspect one live PDP.
5. Inspect both guide pages.
6. Inspect policy pages.
7. Monitor coverage and image indexing.

## Do Not Do Yet

- backlink outreach
- indexing requests
- Merchant Center submission
- image search claims
- public SEO performance claims

## Decision

Post-launch SEO is blocked until production technical readiness is green or explicitly risk-accepted.
