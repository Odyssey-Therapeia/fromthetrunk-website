# Optimized Asset Candidates Report

Date: 2026-07-01

## Candidate Files

| Original | Original Size | Candidate | Candidate Size | Format | Reduction | Code Reference Changed |
| --- | ---: | --- | ---: | --- | ---: | --- |
| `public/hero/banner.png` | 11,229,121 B | `public/seo-candidates/hero-banner-q72.webp` | 278,218 B | WebP | 97.5% | No |
| `public/hero/banner.png` | 11,229,121 B | `public/seo-candidates/hero-banner-q50.avif` | 203,976 B | AVIF | 98.2% | No |
| `public/hero/timeless.JPG` | 7,827,034 B | `public/seo-candidates/hero-timeless-q72.webp` | 995,336 B | WebP | 87.3% | No |
| `public/hero/timeless.JPG` | 7,827,034 B | `public/seo-candidates/hero-timeless-q50.avif` | 645,311 B | AVIF | 91.8% | No |
| `public/hero/banner1.png` | 6,106,267 B | `public/seo-candidates/hero-banner1-q72.webp` | 196,454 B | WebP | 96.8% | No |
| `public/hero/banner1.png` | 6,106,267 B | `public/seo-candidates/hero-banner1-q50.avif` | 148,186 B | AVIF | 97.6% | No |
| `public/banner/collection_banner.png` | 4,254,829 B | `public/seo-candidates/collection-banner-q72.webp` | 200,110 B | WebP | 95.3% | No |
| `public/banner/collection_banner.png` | 4,254,829 B | `public/seo-candidates/collection-banner-q50.avif` | 171,386 B | AVIF | 96.0% | No |
| `public/media/home-cover.png` | 3,020,948 B | `public/seo-candidates/home-cover-q72.webp` | 217,732 B | WebP | 92.8% | No |
| `public/media/home-cover.png` | 3,020,948 B | `public/seo-candidates/home-cover-q50.avif` | 169,819 B | AVIF | 94.4% | No |
| `public/Welcoming.mp4` | 13,616,217 B | `public/seo-candidates/welcoming-1080p-crf30-muted.mp4` | 905,570 B | MP4 | 93.3% | No |
| `public/Welcoming.webm` | 3,171,178 B | `public/seo-candidates/welcoming-1080p-crf36-muted.webm` | 823,127 B | WebM | 74.0% | No |

## Quality Notes

- Image candidates are non-destructive derivatives. They require side-by-side visual approval before replacing live references.
- Video candidates are 1080p muted derivatives. They require intro playback QA before replacing live WebM/MP4 files.
- The WebM transcode emitted an ffmpeg Opus packet warning during generation, but the output file was created and measured. Playback QA is required before use.

## Welcoming Rules Checked

- Current WebM exists.
- Current MP4 fallback exists and is still declared.
- WebM source is first.
- Poster exists.
- Preload is `metadata`.
- No live behavior changed.

